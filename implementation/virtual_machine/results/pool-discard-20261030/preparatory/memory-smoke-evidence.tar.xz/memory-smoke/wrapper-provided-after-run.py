import json
import os
from pathlib import Path
import subprocess

here=Path('/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine')
assets=here/'.local/assets-pool-discard-v3-20261030'
out=here/'.local/pool-discard-memory-smoke2-20261030'
out.mkdir(exist_ok=False)
disk=out/'storage.raw'
subprocess.run(['cp','--sparse=always','--reflink=auto',str(assets/'storage.raw'),str(disk)],check=True)
env=dict(os.environ,CXL_LAB_ASSETS=str(assets),CXL_LAB_SESSION='discard-mem-smoke-20261030',
         CXL_LAB_QEMU_ROOT='/home/ijkim/agent-sandbox-cxl/implementation/virtual_machine/.local/qemu/root')
prefix=['taskset','-c','0-7','python3','-u']
subprocess.run(prefix+[str(here/'lab.py'),'start','--vcpus','4','--memory-mib','8192',
 '--shared-mib','64','--cxl-mib','4096','--dax-guest','--dax-4k','--pool-cow','--migration-network',
 '--network-backend','tap','--memory-backing-dir','/dev/shm','--home-storage-image',str(disk),
 '--qemu','/home/ijkim/agent-sandbox-cxl/implementation/virtual_machine/.local/qemu-cxl/build/qemu-system-x86_64'],
 env=env,cwd=here,check=True)
try:
 subprocess.run(prefix+['/tmp/pool-discard-memory-smoke.py'],env=env,cwd=here,check=True)
finally:
 subprocess.run(['python3',str(here/'lab.py'),'stop'],env=env,cwd=here,check=True)
