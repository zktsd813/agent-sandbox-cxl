import argparse
import json
from pathlib import Path
import shutil
import sys
import time

HERE = Path('/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine')
sys.path.insert(0, str(HERE))
import lab
import nfs_bench as nfs
from home_storage_bench import setup, require
from pool_discard_bench import DiscardController, PoolControl, MIB, PAGE

run, config = lab.current_run()
out = run / ('discard-memory-smoke-' + str(time.time_ns()))
out.mkdir()
shutil.copy2(__file__, out / 'measured-smoke.py')
args = argparse.Namespace(mode='reporting', anon_mib=416, memory_mib=512, vcpus=2,
                          sandboxes=3, minimum_cache_mib=128, io_engine='Async')
c = DiscardController(config, out, args)
control = PoolControl(c)
report = dict(schema='pool-discard-memory-smoke-v1', result='running', receipts=c.receipts,
              commands=c.commands, api_timings=c.api_timings, boots=c.boots)
def save(): lab.save_json(out / 'report.json', report)
save()
try:
    lab.verify(argparse.Namespace(timeout=180))
    nfs.pin_vms(config, argparse.Namespace(host_cpus_a='0-3', host_cpus_b='4-7'))
    setup(c)
    for role in ('A', 'B'):
        c.shell(role, 'echo 1048576 > /proc/sys/vm/max_map_count\n'
            'echo never > /sys/kernel/mm/transparent_hugepage/enabled', 'system-policy')
    c.shell('A', f'mkdir -p {c.storage}', 'storage-directory')
    report['canonical_setup'] = control.setup()
    s = c.sandboxes[0]
    c.hostwarm()
    c.boot_vm(s)
    c.treatment(s, control, 'smoke-before')
    report['before'] = before = c.audit_pooled(s, control)
    original = {row[1]: row[3] for row in [list(map(int, l.split()))
                for l in (out / before['pfns_file']).read_text().splitlines()]}
    host, _ = c.report_log(s)
    trace = c.trace(s)
    _, sequence = c.guest_ack_pages(trace)
    report['evicted'] = c.command_vm(s, 'evict')
    report['waited'] = c.wait_reported(s, set(original), host['maximum_batch'], sequence)
    report['memory'] = memory = c.command_vm(s, 'identity')
    receipt = memory['receipt']
    print('MEMORY_COUNTS ' + json.dumps(receipt), flush=True)
    c.anon_mib = min(448, (receipt['mem_free_kib']//1024 - 24)//8*8,
                     (receipt['mem_available_kib']//1024 - 16)//8*8)
    require(c.anon_mib >= 384, 'Insufficient safe memory for large-reuse smoke')
    report['selected_anon_mib'] = c.anon_mib
    report['allocated'] = c.command_vm(s, 'anon_alloc', c.anon_mib)
    report['filled'] = c.command_vm(s, 'anon_fill')
    report['verified'] = c.command_vm(s, 'anon_verify')
    mapped = c.command_vm(s, 'anonmap')
    c.pause(s)
    try:
        report['anonymous'], values = c.scan_anon(s, mapped)
    finally:
        c.resume(s)
    private = {row[1]: row[3] for row in values}
    reused = set(private) & set(original)
    changed = {g for g in reused if private[g] != original[g]}
    report.update(reused_pages=len(reused), changed_pages=len(changed))
    require(reused == changed and len(reused)*PAGE >= 128*MIB, 'Large-reuse smoke threshold failed')
    report['freed'] = c.command_vm(s, 'anon_free')
    report['result'] = 'passed'
except BaseException as exc:
    report['result'], report['error'] = 'failed', repr(exc)
    raise
finally:
    for s in c.sandboxes:
        if s.directory:
            c.fetch_bytes(s.role, s.directory+'/fc.log', f'vm{s.vm}-final-log')
            nfs.stop_fc(c.vms[s.role], s.directory)
    save()
    print('MEMORY_SMOKE_REPORT ' + str(out / 'report.json'), flush=True)
