import argparse
import json
from pathlib import Path
import shutil
import sys
import time

HERE=Path('/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine')
sys.path.insert(0,str(HERE))
import lab
import nfs_bench as nfs
from home_storage_bench import setup, require
from pool_discard_bench import DiscardController, PoolControl
from pool_cow_trace import profile_recycle

run,config=lab.current_run()
out=run/('discard-cow-diagnostic-'+str(time.time_ns()));out.mkdir()
(out/'measured-sources').mkdir()
shutil.copy2(__file__,out/'measured-sources/diagnostic.py')
for name in ('pool_cow_trace.py','pool_discard_bench.py','pool_discard_probe.c'):
    shutil.copy2(HERE/name,out/'measured-sources'/name)
args=argparse.Namespace(mode='baseline',anon_mib=400,memory_mib=512,vcpus=2,
    sandboxes=3,minimum_cache_mib=128,io_engine='Async')
c=DiscardController(config,out,args);control=PoolControl(c)
report=dict(schema='pool-discard-cow-diagnostic-v1',result='running',receipts=c.receipts,
    commands=c.commands,api_timings=c.api_timings,boots=c.boots)
def save():lab.save_json(out/'report.json',report)
save()
try:
    lab.verify(argparse.Namespace(timeout=180))
    nfs.pin_vms(config,argparse.Namespace(host_cpus_a='0-3',host_cpus_b='4-7'))
    setup(c)
    for role in ('A','B'):
        c.shell(role,'echo 1048576 > /proc/sys/vm/max_map_count\n'
            'echo never > /sys/kernel/mm/transparent_hugepage/enabled','system-policy')
    c.shell('A',f'mkdir -p {c.storage}','storage-directory')
    report['canonical_setup']=control.setup()
    s=c.sandboxes[0]
    c.hostwarm();c.boot_vm(s);c.treatment(s,control,'fresh-before-profile')
    report['before']=before=c.audit_pooled(s,control)
    report['hot']=c.command_vm(s,'check',require_cache=True)
    report['profile']=profile_recycle(c,s)
    c.pause(s)
    try:report['after'],values=c.scan(s,reuse=before)
    finally:c.resume(s)
    old=[list(map(int,l.split())) for l in (out/before['pfns_file']).read_text().splitlines()]
    report['original_cache_gpas_with_changed_pfns']=sum(a[3]!=b[3] for a,b in zip(old,values))
    report['canonical_check']=c.verify_canonical()
    c.hostwarm();report['refill']=c.command_vm(s,'warm',require_cache=True)
    c.treatment(s,control,'after-profile-refill')
    report['final']=c.command_vm(s,'check',require_cache=True)
    report['result']='passed'
except BaseException as exc:
    report['result'],report['error']='failed',repr(exc)
    raise
finally:
    for s in c.sandboxes:
        if s.directory:
            for log in ('fc','vmm','stderr'):
                c.fetch_bytes(s.role,s.directory+'/'+log+'.log',f'vm{s.vm}-final-{log}-log')
            nfs.stop_fc(c.vms[s.role],s.directory)
    save();print('COW_DIAGNOSTIC_REPORT '+str(out/'report.json'),flush=True)
