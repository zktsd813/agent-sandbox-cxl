import hashlib,json,os,pathlib,re,subprocess,time
root=pathlib.Path('/tmp/firecracker-home-storage-20261028')
out=pathlib.Path('/tmp/pool-fc-checks-20261030')
deps=root/'build/cargo_target/x86_64-unknown-linux-musl/release/deps'
vmm=deps/'vmm-978564fa50d4521a'
checks=[('pool_cache',vmm,'pool_cache'),('prepare_save',vmm,'test_prepare_save'),
('snapshot_flush_failure',vmm,'test_storage_snapshot_flush_failure_writes_no_checkpoint'),
('direct_preflight',vmm,'test_direct_handoff_preflight_rejects_devices_and_multiple_vcpus'),
('preboot_disallowed',vmm,'rpc_interface::tests::test_preboot_disallowed'),
('create_guest_memory',vmm,'test_create_guest_memory'),
('actions_library',deps/'firecracker-0329863cef8274ab','test_parse_put_actions'),
('actions_binary',deps/'firecracker-ab6108b01fbdcf3a','test_parse_put_actions')]
records=[]
env={k:v for k,v in os.environ.items() if not k.startswith('FC_')}
for name,binary,flt in checks:
    start=time.monotonic()
    result=subprocess.run([str(binary),flt,'--nocapture','--test-threads=1'],env=env,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
    (out/(name+'.log')).write_text(result.stdout)
    record={'name':name,'filter':flt,'exit_code':result.returncode,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'log':name+'.log','tests_passed':sum(map(int,re.findall(r'test result: ok\. (\d+) passed',result.stdout)))}
    records.append(record)
    print(json.dumps(record),flush=True)
release=root/'build/cargo_target/x86_64-unknown-linux-musl/release/firecracker'
summary={'checks':records,'all_passed':all(x['exit_code']==0 and x['tests_passed']>0 for x in records),'runtime_sha256':hashlib.sha256(release.read_bytes()).hexdigest(),'pooling_environment':'FC_* removed for all checks','source_pool_module_sha256':hashlib.sha256((root/'src/vmm/src/pool_cache.rs').read_bytes()).hexdigest()}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
raise SystemExit(0 if summary['all_passed'] else 1)
