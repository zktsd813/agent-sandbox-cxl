#!/usr/bin/env python3
"""Exercise the exact source_fence_script with synthetic proc files and BusyBox sh.

No real /proc access, signals, or VMs are used. Only the returned script's
literal /proc/ prefix is replaced; cat functions inject controlled read races.
"""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir',type=Path,default=Path('/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine'))
    parser.add_argument('--busybox',type=Path,default=Path(shutil.which('busybox')))
    parser.add_argument('--json-out',type=Path,default=Path('/tmp/source-fence-tests.json'))
    args=parser.parse_args()
    sys.path.insert(0,str(args.source_dir.resolve()))
    module=importlib.import_module('trace_bench')
    busybox=args.busybox.resolve()
    tests=[]
    with tempfile.TemporaryDirectory(prefix='source-fence-test-') as temporary:
        root=Path(temporary)
        bins=root/'bin';bins.mkdir()
        for applet in ('cat','rm'):(bins/applet).symlink_to(busybox)
        def stat(state='R',start='123'):
            return '777 (firecracker) '+state+' '+' '.join(['0']*18+[start])+'\n'
        cases=[
            ('live_R_same_incarnation',stat('R'),None,False,None),
            ('live_S_same_incarnation',stat('S'),None,False,None),
            ('zombie_same_incarnation',stat('Z'),None,True,('Z','123')),
            ('dead_X_same_incarnation',stat('X'),None,True,('X','123')),
            ('different_start_reused',stat('R','999'),None,True,('reused','999')),
            ('missing_process',None,None,True,('missing','0')),
            ('cat_reap_race',stat('Z'),'remove_then_fail',True,('missing','0')),
            ('cat_fail_entry_present',stat('Z'),'fail',False,None),
            ('truncated_stat','777 (firecracker) Z 0\n',None,False,None),
            ('malformed_short_stat','malformed stat\n',None,False,None),
            ('malformed_starttime',stat('Z','broken'),None,False,None),
            ('missing_starttime_field',stat('Z',''),None,False,None),
            ('zero_starttime',stat('Z','0'),None,False,None),
        ]
        bad_records={'bad_pid_non_numeric':'broken 123\n','bad_pid_zero':'0 123\n','bad_pid_one':'1 123\n','bad_pid_negative':'-777 123\n','bad_expected_non_numeric':'777 broken\n','bad_expected_zero':'777 0\n','bad_expected_negative':'777 -123\n','missing_expected':'777\n'}
        cases.extend((name,stat('Z'),None,False,None) for name in bad_records)
        for name,content,fault,accepted,expected in cases:
            folder=root/name;folder.mkdir();(folder/'fc.pid').write_text(bad_records.get(name,'777 123\n'))
            proc=folder/'proc'/'777';proc.mkdir(parents=True);statefile=proc/'stat'
            if content is not None:statefile.write_text(content)
            original=module.source_fence_script(str(folder))
            body=original.replace('/proc/',str(folder/'proc')+'/')
            prefix='set -e\n'
            if fault=='remove_then_fail':prefix+='cat() { rm -- '+shlex.quote(str(statefile))+'; return 1; }\n'
            elif fault=='fail':prefix+='cat() { return 1; }\n'
            result=subprocess.run([str(busybox),'sh','-c',prefix+body],env={**os.environ,'PATH':str(bins)},capture_output=True,text=True)
            expected_stdout=('FENCED 777 123\nFENCE_STATE '+expected[0]+' '+expected[1]+'\n') if accepted else None
            correct=(result.returncode==0 and result.stdout==expected_stdout) if accepted else (result.returncode!=0 and 'FENCED ' not in result.stdout)
            tests.append({'case':name,'expected':'accepted' if accepted else 'rejected','result':'passed' if correct else 'failed','exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
    output={'result':'passed' if all(t['result']=='passed' for t in tests) else 'failed','source_file':str(args.source_dir/'trace_bench.py'),'source_sha256':hashlib.sha256((args.source_dir/'trace_bench.py').read_bytes()).hexdigest(),'script_template_sha256':hashlib.sha256(module.source_fence_script('/run/trace-test').encode()).hexdigest(),'busybox':str(busybox),'cpu_affinity':sorted(os.sched_getaffinity(0)),'tests':tests}
    args.json_out.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output,indent=2))
    return 0 if output['result']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
