import argparse, copy, importlib.util, json, pathlib, sys, tempfile
from unittest import mock
base=pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0,str(base))
import nfs_bench as bench
import verify_nfs_results as verifier
root=pathlib.Path(tempfile.mkdtemp(prefix='nfs-host-observation-tests-'))
raw=['COUNTERS=100 200 10\nMOUNT_READ=10 1000 2000\n','COUNTERS=300 400 12\nMOUNT_READ=12 1200 4000\n']
resident={'event':'resident','label':'host','pid':1,'open_cookie':'0001','offset':0,'bytes':8192,'pages':2,'resident_before':0,'resident_after':0}
cache={'B':[{'path':'/disk/sandbox.raw','size':8192,'text':json.dumps(resident,separators=(',',':'))+'\n'}]}
filename=bench.save_host_observation(root,'s1_retained_seq',raw,cache)
row={'label':'s1_retained_seq','host_observation_file':filename,'host_cache_state':{'B_image_resident_pages':0},'network_delta':{'rx_bytes':200,'tx_bytes':200,'nfs_read_calls':2,'mount_read_ops':2,'mount_read_sent_bytes':200,'mount_read_received_bytes':2000}}
verifier.audit_host_observation(row,root,8192)
passed=['valid_raw_snapshot']
def reject(name,func):
    try:func()
    except (AssertionError,ValueError,FileNotFoundError,KeyError,RuntimeError):passed.append(name)
    else:raise AssertionError(name+' unexpectedly accepted')
changed=copy.deepcopy(row);changed['network_delta']['nfs_read_calls']*=1000
reject('derived_counter_forgery',lambda:verifier.audit_host_observation(changed,root,8192))
changed=copy.deepcopy(row);changed['host_cache_state']['B_image_resident_pages']=2
reject('derived_cache_forgery',lambda:verifier.audit_host_observation(changed,root,8192))
original=(root/filename).read_text();obj=json.loads(original);obj['before']+='COUNTERS=100 200 10\n';(root/filename).write_text(json.dumps(obj))
reject('duplicate_raw_counter_line',lambda:verifier.audit_host_observation(row,root,8192))
obj=json.loads(original);obj['cache']['B'][0]['size']=4096;(root/filename).write_text(json.dumps(obj))
reject('wrong_raw_range',lambda:verifier.audit_host_observation(row,root,8192))
(root/filename).unlink();reject('missing_raw_evidence',lambda:verifier.audit_host_observation(row,root,8192))
reject('invalid_evidence_filename',lambda:bench.save_host_observation(root,'../outside',raw))
commands=[];claimed=set()
def fake_shell(vm,body,timeout=60):
    commands.append((vm['role'],body))
    if body.startswith('if [ -e /run/nfs-storage-claimed') and vm['role'] in claimed:raise RuntimeError('already used')
    if body.startswith('mkdir /run/nfs-storage-claimed'):claimed.add(vm['role'])
    return 'captured observation'
a,b={'role':'A'},{'role':'B'}
with mock.patch.object(bench,'shell',fake_shell):
    env=bench.setup_storage(a,b,'/run/nfs-test','trace.raw')
    assert set(env)=={'A-environment','B-environment','mounts'}
    assert any('/storage/trace.raw' in body for _,body in commands)
    assert any('/remote/trace.raw' in body for _,body in commands)
    assert not any('sandbox.raw' in body for _,body in commands)
    count=len(commands)
    reject('single_use_pair_guard',lambda:bench.setup_storage(a,b,'/run/nfs-other','trace.raw'))
    assert len(commands)==count+1
passed.append('dynamic_image_setup')
config={'vms':{'A':{'pid':123,'starttime':'x'},'B':{'pid':456,'starttime':'y'}}}
cpus=sorted(__import__('os').sched_getaffinity(0))
with mock.patch.object(bench.lab,'alive',return_value=False), mock.patch.object(bench.os,'sched_setaffinity') as affinity:
    reject('dead_vm_affinity_guard',lambda:bench.pin_vms(config,argparse.Namespace(host_cpus_a=str(cpus[0]),host_cpus_b=None)))
    affinity.assert_not_called()
print(json.dumps({'result':'passed','tests':passed,'temporary_directory':str(root)},indent=2))
