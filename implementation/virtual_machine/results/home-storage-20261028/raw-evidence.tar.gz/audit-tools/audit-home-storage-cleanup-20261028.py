#!/usr/bin/env python3
"""Read-only post-stop audit of resources named by microVM lab reports.

Run on the real host after all owned lab VMs have stopped, for example:
  sudo python3 audit-home-storage-cleanup-20261028.py REPORT... --out AUDIT.json

Embedded report.config, raw run.json, and reports naming run/run.json are
supported. No process is signalled, socket contacted, resource deleted, or VM
started. The only write is the new --out JSON. Namespace identity is recorded;
an elevated caller must choose the real host namespaces. Optional expected
namespace arguments pin an independently established host namespace identity.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def absolute_path(value, label):
    require(isinstance(value, str) and value and "\0" not in value,
            f"{label}: missing or invalid path")
    path = Path(value)
    require(path.is_absolute(), f"{label}: expected an absolute path")
    return path


def observer():
    namespaces = {name: os.readlink(f"/proc/self/ns/{name}") for name in ("pid", "net", "mnt", "user")}
    nspid = []
    for line in Path("/proc/self/status").read_text().splitlines():
        if line.startswith("NSpid:"):
            nspid = [int(value) for value in line.split()[1:]]
    return {"pid": os.getpid(), "euid": os.geteuid(), "namespaces": namespaces,
            "procfs_pid1_pid_namespace": os.readlink("/proc/1/ns/pid"),
            "nspid": nspid, "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
            "scope": "Only resources visible in these namespaces; real-host execution is caller's responsibility."}


def load_config(report_path):
    raw = report_path.read_bytes()
    report = json.loads(raw)
    require(isinstance(report, dict), "Report must be a JSON object")
    origin = str(report_path)
    if isinstance(report.get("config"), dict):
        config, location = report["config"], "embedded config"
    elif isinstance(report.get("vms"), dict):
        config, location = report, "run configuration"
    elif isinstance(report.get("info"), dict) and isinstance(report["info"].get("config"), dict):
        config, location = report["info"]["config"], "embedded info.config"
    else:
        run = absolute_path(report.get("run"), "Report run")
        config_path = run / "run.json"
        config = json.loads(config_path.read_bytes())
        location, origin = "referenced run.json", str(config_path)
    require(isinstance(config, dict), "Configuration must be a JSON object")
    run = absolute_path(config.get("run"), "Configuration run")
    if report.get("run") is not None:
        require(absolute_path(report["run"], "Report run") == run,
                "Report and configuration name different run directories")
    require(isinstance(config.get("vms"), dict) and bool(config["vms"]),
            "Configuration has no recorded QEMU processes")
    return report, config, {"location": location, "path": origin,
                            "report_sha256": hashlib.sha256(raw).hexdigest()}


def process_check(role, vm):
    require(isinstance(vm, dict), f"QEMU {role}: malformed record")
    pid, start = vm.get("pid"), str(vm.get("starttime", ""))
    require(isinstance(pid, int) and not isinstance(pid, bool) and pid > 1,
            f"QEMU {role}: invalid recorded PID")
    require(start.isdigit() and int(start) > 0, f"QEMU {role}: invalid recorded starttime")
    result = {"role": role, "recorded_pid": pid, "recorded_starttime": start}
    try:
        text = Path(f"/proc/{pid}/stat").read_text()
    except (FileNotFoundError, ProcessLookupError):
        return dict(result, owned_incarnation_dead=True, reason="PID absent")
    except OSError as exc:
        raise RuntimeError(f"QEMU {role}: cannot inspect recorded PID {pid}, errno {exc.errno}") from exc
    closing = text.rfind(")")
    require(closing >= 0, f"QEMU {role}: malformed proc stat")
    fields = text[closing + 2:].split()
    require(len(fields) > 19 and fields[19].isdigit(), f"QEMU {role}: incomplete proc identity")
    if fields[19] != start:
        # Do not expose the replacement process's name, state, starttime, UID,
        # command, or any other details. Only the recorded identity is output.
        return dict(result, owned_incarnation_dead=True, reason="PID has a different incarnation")
    dead = fields[0] in {"Z", "X", "x"}
    return dict(result, owned_incarnation_dead=dead, owned_process_state=fields[0],
                reason="Owned process exited" if dead else "Owned process is still alive")


def path_check(label, value):
    if value is None:
        return {"resource": label, "applicable": False, "reason": "Not configured"}
    path = absolute_path(value, label)
    try:
        path.lstat()  # A dangling symlink is still a leftover resource.
    except (FileNotFoundError, NotADirectoryError):
        return {"resource": label, "path": str(path), "applicable": True, "absent": True}
    except OSError as exc:
        raise RuntimeError(f"{label}: cannot inspect {path}, errno {exc.errno}") from exc
    return {"resource": label, "path": str(path), "applicable": True, "absent": False}


def network_expectations(config):
    network = config.get("migration_network") or {}
    if network.get("backend") != "tap":
        return None
    nonce = config.get("nonce")
    require(isinstance(nonce, str) and re.fullmatch(r"[0-9a-f]{16}", nonce), "TAP network: invalid run nonce")
    owned = network.get("host_network")
    require(isinstance(owned, dict), "TAP network: missing ownership record")
    alias = "cxl-lab:" + nonce
    require(owned.get("alias") == alias, "TAP network: ownership alias does not match run nonce")
    objects = owned.get("objects")
    require(isinstance(objects, dict) and set(objects) == {"bridge", "A", "B"},
            "TAP network: expected bridge, A, and B ownership records")
    token = nonce[:8]
    expected_names = {"bridge": "cxb" + token, "A": "cxt" + token + "a", "B": "cxt" + token + "b"}
    for role, name in expected_names.items():
        require(isinstance(objects[role], dict) and objects[role].get("name") == name,
                f"TAP network {role}: interface name does not match owned nonce")
    return alias, expected_names


def read_links():
    ip = shutil.which("ip")
    require(ip is not None, "Host ip command is unavailable")
    argv = [ip, "-json", "-details", "link", "show"]
    try:
        result = subprocess.run(argv, capture_output=True, text=True, timeout=10,
                                env=dict(os.environ, LC_ALL="C"))
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError("ip -json link query timed out after 10 seconds") from exc
    require(result.returncode == 0, f"ip -json link query failed with exit {result.returncode}")
    rows = json.loads(result.stdout)
    require(isinstance(rows, list) and all(isinstance(row, dict) for row in rows),
            "ip -json link query returned malformed JSON")
    # The complete link list is never written to the audit output.
    return rows, argv


def audit_one(path, links_cache):
    result = {"report": str(path), "result": "failed", "errors": [],
              "processes": [], "paths": [], "network": None}
    errors = result["errors"]
    try:
        report, config, source = load_config(path)
        result.update(config_source=source, run=config["run"], input_result=report.get("result"),
                      input_case=report.get("case"))
        for role, vm in sorted(config["vms"].items()):
            try:
                check = process_check(role, vm)
                result["processes"].append(check)
                if not check["owned_incarnation_dead"]:
                    errors.append(f"QEMU {role}: recorded PID {check['recorded_pid']} with expected starttime is still alive")
            except Exception as exc:
                errors.append(str(exc))
        require(config.get("control_dir") is not None, "Missing control_dir ownership path")
        paths = [(key, config.get(key)) for key in ("control_dir", "ephemeral_memory_dir", "cxl_backing")]
        if config.get("ephemeral_memory_dir") is not None:
            paths.append(("shared_backing", config.get("backing")))
        for role, vm in sorted(config["vms"].items()):
            require(vm.get("qmp") is not None, f"QEMU {role}: missing QMP endpoint path")
            paths.extend([(f"QEMU {role} QMP", vm["qmp"]), (f"QEMU {role} console", vm.get("console"))])
        for label, value in paths:
            try:
                check = path_check(label, value)
                result["paths"].append(check)
                if check.get("applicable") and not check["absent"]:
                    errors.append(f"Leftover {label}: {check['path']}")
            except Exception as exc:
                errors.append(str(exc))
        network = network_expectations(config)
        if network is None:
            result["network"] = {"applicable": False, "reason": "No owned host TAP network configured"}
        else:
            alias, expected_names = network
            if not links_cache:
                rows, argv = read_links()
                links_cache.update(rows=rows, argv=argv)
            rows = links_cache["rows"]
            checks = [{"role": role, "name": name,
                       "absent": not any(row.get("ifname") == name for row in rows)}
                      for role, name in expected_names.items()]
            # An owned interface renamed after setup must not evade the check.
            alias_matches = [{"name": row.get("ifname"), "ifindex": row.get("ifindex")}
                             for row in rows if row.get("ifalias") == alias]
            result["network"] = {"applicable": True, "query": links_cache["argv"],
                                 "ownership_alias": alias, "expected_interfaces": checks,
                                 "interfaces_still_carrying_owned_alias": alias_matches}
            for check in checks:
                if not check["absent"]:
                    errors.append(f"Recorded {check['role']} interface still exists: {check['name']}")
            if alias_matches:
                errors.append(f"Interfaces still carry this run's ownership alias: {alias}")
    except Exception as exc:
        errors.append(f"{type(exc).__name__}: {exc}")
    result["result"] = "failed" if errors else "passed"
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", nargs="*", type=Path)
    parser.add_argument("--report", action="append", default=[], type=Path,
                        help="Additional report; may be repeated instead of positional paths")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--expected-pid-namespace", help="Optional independently established host pid:[inode]")
    parser.add_argument("--expected-net-namespace", help="Optional independently established host net:[inode]")
    args = parser.parse_args()
    paths = list(dict.fromkeys(path.absolute() for path in args.reports + args.report))
    if not paths:
        parser.error("At least one report path is required")
    if os.path.lexists(args.out):
        parser.error("--out already exists; refusing to replace previous evidence")
    audit = {"schema_version": 1, "recorded_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
             "result": "failed", "read_only_resource_audit": True, "reports": [], "errors": [],
             "semantics": "Owned PID incarnation must be absent/exited; configured control/memory/socket paths and owned network names/alias must be absent. This is a point-in-time observation."}
    try:
        audit["observer"] = observer()
        require(os.geteuid() == 0, "Run this audit elevated on the real host; unprivileged namespace absence is insufficient")
        for name, expected in (("pid", args.expected_pid_namespace), ("net", args.expected_net_namespace)):
            if expected is not None:
                require(audit["observer"]["namespaces"][name] == expected,
                        f"Observer {name} namespace does not match the expected host namespace")
        links_cache = {}
        audit["reports"] = [audit_one(path, links_cache) for path in paths]
        if all(row["result"] == "passed" for row in audit["reports"]):
            audit["result"] = "passed"
    except Exception as exc:
        audit["errors"].append(f"{type(exc).__name__}: {exc}")
    with args.out.open("x") as stream:
        json.dump(audit, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"result": audit["result"], "out": str(args.out), "reports": len(audit["reports"])}))
    return 0 if audit["result"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
