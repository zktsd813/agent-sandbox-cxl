#!/usr/bin/env python3
import hashlib,json
from pathlib import Path
out=Path('/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine/results/home-storage-20261028')
def read(name):return json.loads((out/name).read_text())
def count(items,key='result',expected='rejected'):return sum(i.get(key)==expected for i in items)
h=read('home-report.json');ha=read('home-audit.json');d=read('disk-audit.json');dr=read('direct-audit.json')
t=read('trace-report.json');ta=read('trace-audit.json');tn=read('trace-negative-tests.json');build=read('build.json')
assert all(v['result']=='passed' for v in (h,ha,d,dr,t,ta,tn,build,read('cleanup.json'),read('packaging-audit.json')))
assert len(t['trials'])==24 and ta['commands']==840 and ta['handoffs']==48
assert ta['ram_copied_bytes']==96*1024**3 and sum(x['ram_transfer_bytes'] for x in h['transitions'])==3*1024**3
assert count(tn['negative_cases'])==40 and count(ha['negative_tests'])==31
assert count(dr['negative_tests'],'rejected',True)==42 and count(d['negative_cases'])==6
summary={'schema_version':1,'date':'2026-10-28','result':'passed','purpose':'Home-owned writable disk plus snapshot DRAM/CXL lifecycle correctness; direct unsupported configurations remain rejected',
 'home':{'cycles':3,'transitions':12,'commands':74,'guest_events':ha['guest_events'],'ram_copied_bytes':sum(x['ram_transfer_bytes'] for x in h['transitions']),
 'cxl_only_ram_copy_bytes':sum(x['ram_transfer_bytes'] for x in h['transitions'] if x['source_tier']==x['destination_tier']=='cxl'),
 'fresh_boot_persistence':True,'full_log_files':ha['full_firecracker_logs'],'raw_state_files_compared':ha['state_files_byte_compared'],'evidence_mutations_rejected':31},
 'disk':{'pattern_words_checked':d['pattern_words_checked'],'actual_image_corruptions_rejected':6,'clean_shutdown_only':True,'inner_sha256':d['inner']['sha256'],'outer_sha256':d['outer']['sha256']},
 'trace':{key:ta[key] for key in ('trials','commands','handoffs','recorded_exits_checked','submission_exits_checked','submissions_checked','stable_test_summaries_checked','ram_copied_bytes','native_ram_phases_checked','native_mailbox_phases_checked','native_api_phases_checked','ram_lifecycle','state_transport')},
 'direct':{'supported_diskless_handoffs':20,'unsupported_cases_safely_rejected':2,'evidence_mutations_rejected':42,'block_migration_supported':False},
 'build':{'firecracker_sha256':build['binary_sha256'],'patch_sha256':build['patch_sha256'],'base_revision':build['base_revision'],'selected_tests_passed':build['selected_tests_passed']},
 'research':{'confirmed_agent_rl_tmpfs_examples':['NVIDIA NeMo-Gym / Nemotron 3 Super','Aleph Alpha Kolibri'],'containers_not_cxl_migration':True},
 'limitations':['One coherent physical-host nested KVM lab','Stop-and-copy at DRAM/CXL tier changes; no latency claim','Controller-only writer fencing, no distributed failure recovery','No power-loss durability claim','Real trace uses RO disk plus guest tmpfs upper; persistent ext4 tested separately','Direct block migration and PML/MPTCP integration remain future work']}
summary['trace']['evidence_mutations_rejected']=40
summary['trace']['submission_normalization']=ta['submission_normalization']
summary['trace']['expected_nonzero_exits']=sum(int(c['rc'])!=0 for x in t['trials'] for c in x['commands'])
(out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
s=(out/'README.md').read_text()
s=s.replace('FINAL_RESULTS_PENDING','''| 시험 | 최종 결과 | 독립 확인 |
|---|---|---|
| Writable ext4, 3회 전체 왕복 | **12 transitions · 74 workload commands** | Guest 이벤트 98개, 전체 FC 로그 14개, state 파일 24개 byte 비교 |
| 종료된 실제 disk | **10,494,464 words 전수 비교** | Outer/inner ext4 fsck, UUID·내용 hash 일치, 실제 image 손상 6종 탐지 |
| 실제 trace, local/NFS × cache 유지 3회·회수 1회 | **24 trials · 840 commands · 48 transitions** | 원본 종료값 816개·제출 24개·테스트 요약 72개, patch·열린 FD 일치 |
| Direct unsupported block/2-vCPU | **두 구성 모두 안전하게 거절** | Resume 없이 block cold read / guest counter 진행, owner·generation 불변 |
| 기존 1-vCPU diskless direct | **20 handoffs** | 한 번 부팅, snapshot 0, VM/vCPU/EPT identity 유지 |

Home 시험은 RAM 512MiB를 promotion/demotion 때 총 **3GiB** 복사했고, CXL에 머문 6회 handoff에서는 0 byte다.
Trace 시험은 2GiB RAM을 48번 tier 전환해 총 **96GiB** 복사했다. 모든 native import/export는
전체 byte 비교를 수행했으며 demotion 뒤 CXL poison 검사도 통과했다.
Trace의 기대된 nonzero 종료 48건도 원본과 일치한다. 이 숫자는 실패한 migration의 개수가 아니다.
MicroPython 8회는 기존 conda startup warning의 출력 위치가 달라 raw submission hash가 다르다.
기존 검증 규칙대로 해당 한 줄만 제거하고 출현 횟수는 같음을 확인했으며, 정규화한 patch bytes는 일치했다.
원시 출력도 그대로 보관하므로 임의의 stderr나 test 실패를 숨기는 정규화는 아니다.

독립 verifier에는 home 증거 변조 **31개**, trace 증거 변조 **40개**, direct 증거 변조 **42개**를
넣어 모두 거부됨을 확인했다. 실제 disk bytes를 바꾼 6개 검사는 이 metadata/receipt 변조 검사와 별도다.
RAM helper의 75 unit 검사·19 CLI 오류 입력·ASan/UBSan 검사, 파일 probe의 22 오류 입력,
Firecracker의 fsync 실패·snapshot 미생성·API dispatch 등 선택 회귀 11개도 통과했다.
LeakSanitizer는 실행 환경의 ptrace 제약으로 지원되지 않아 비활성화했으며 해당 실패 기록은 보존한다.''')
s=s.replace('EVIDENCE_LINKS_PENDING','''[전체 요약](summary.json) · [Home report](home-report.json) · [Home audit](home-audit.json) ·
[최종 disk audit](disk-audit.json) · [Trace report](trace-report.json) · [Trace audit](trace-audit.json) ·
[Trace 오류 주입](trace-negative-tests.json) · [Direct audit](direct-audit.json) · [빌드·회귀](build.json) ·
[선행 사례](research.json) · [자원 정리](cleanup.json) · [새 디렉터리에서의 재검증](packaging-audit.json) ·
[원시 자료](raw-evidence.tar.gz) · [최종 disk](final-home-storage.raw.gz) · [파일 hash 목록](manifest.json)

최종 disk archive는 약 80MiB이며 하나의 canonical outer image만 보관한다.
원시 자료에는 full RAM payload나 큰 prepared trace image를 중복 포함하지 않는다.
RAM 동일성은 native full-byte-comparison receipt로 확인하고, 작은 CPU/device state bytes는 archive에서 직접 다시 비교한다.
Runtime 당시 prepared artifact 13개도 확인했으며 큰 prepared image를 가진 경우 trace auditor에 `--artifacts`를 추가한다.''')
s=s.replace('OFFLINE_COMMANDS_PENDING','''```bash
mkdir -p /tmp/home-evidence
tar -xzf implementation/virtual_machine/results/home-storage-20261028/raw-evidence.tar.gz -C /tmp/home-evidence
python3 /tmp/home-evidence/audit-tools/verify_home_storage.py \\
  /tmp/home-evidence/home/report.json --full-patterns --negative-tests --out /tmp/home-audit.json
python3 /tmp/home-evidence/audit-tools/verify_trace_results.py \\
  /tmp/home-evidence/trace/report.json --formal --json-out /tmp/trace-audit.json
python3 /tmp/home-evidence/audit-tools/audit-safe-direct.py \\
  /tmp/home-evidence/direct/direct-block /tmp/home-evidence/direct/direct-two-vcpu \\
  /tmp/home-evidence/direct/direct-baseline --out /tmp/direct-audit.json
gzip -dc implementation/virtual_machine/results/home-storage-20261028/final-home-storage.raw.gz \\
  > /tmp/home-evidence/home-storage.raw
python3 /tmp/home-evidence/audit-tools/audit-home-storage-disk.py \\
  --report /tmp/home-evidence/home/report.json --disk /tmp/home-evidence/home-storage.raw \\
  --probe /tmp/home-evidence/tools/home-storage-probe --offline-copy --out /tmp/disk-audit.json
```

`--offline-copy`는 현재 host에서 과거 VM의 종료를 다시 입증하지 않는다. 종료 당시의 관측은
`cleanup.json`과 disk audit의 `shutdown`에 남아 있다. Detached copy에서는 filesystem과 실제 저장 내용,
이미지 손상 탐지까지 다시 검증한다.''')
s=s.replace('prepared artifact 13개',f"prepared artifact {len(ta['artifact_files_checked'])}개")
assert summary['trace']['expected_nonzero_exits']==48
assert '_PENDING' not in s
(out/'README.md').write_text(s)
m=read('manifest.json')
for name in ('summary.json','README.md'):
 p=out/name;m['files'][name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
