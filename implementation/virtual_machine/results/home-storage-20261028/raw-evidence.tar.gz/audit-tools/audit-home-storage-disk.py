#!/usr/bin/env python3
"""Read-only disk audit after the owned home-storage lab has stopped.

No host filesystem mounts. e2fsck -fn and debugfs read the retained outer ext4;
debugfs extracts the guest image and files. Six negative cases change actual
file-data bytes in disposable guest-image copies. No production VM is started.

For a detached published copy, use --disk COPY --probe BINARY --offline-copy.
That mode cannot establish historical process shutdown; the original live-host
audit records those observations. This proves clean-shutdown persistence, not
power-loss durability.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import time

MASK = (1 << 64) - 1
MULTIPLIER = 0xD6E8FEB86659FD93
TAGS = {"mutable.bin": 0x4D555441424C4500, "mapped.bin": 0x4D415050494E4700,
        "payload.bin": 0x5041594C4F414400, "cursor.bin": 0x435552534F520000}
HASH_FIELDS = {"mutable.bin": "mutable_hash", "mapped.bin": "mapped_hash",
               "payload.bin": "payload_hash", "cursor.bin": "cursor_hash"}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def mix(value):
    value = (value + 0x9E3779B97F4A7C15) & MASK
    value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & MASK
    value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & MASK
    return value ^ (value >> 31)


def pattern_file(path, tag, generation, expected_bytes):
    """Independent Python word oracle and FNV; does not call the C generator."""
    require(path.stat().st_size == expected_bytes and expected_bytes % 8 == 0,
            f"Incorrect size for {path.name}")
    seed = tag ^ ((generation * MULTIPLIER) & MASK)
    index, fnv = 0, 14695981039346656037
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            for (actual,) in struct.iter_unpack("<Q", data):
                expected = mix(seed ^ index)
                require(actual == expected, f"Pattern mismatch: {path.name} word {index}")
                index += 1
            for value in data:
                fnv = ((fnv ^ value) * 1099511628211) & MASK
    return {"bytes": expected_bytes, "words": index, "fnv1a64": f"{fnv:016x}"}


def process_state(vm):
    pid, expected = int(vm["pid"]), str(vm["starttime"])
    require(pid > 1 and expected.isdigit(), "Invalid recorded QEMU identity")
    try:
        record = Path(f"/proc/{pid}/stat").read_text()
    except (FileNotFoundError, ProcessLookupError):
        return {"pid": pid, "expected_starttime": expected, "reason": "missing", "alive": False}
    fields = record[record.rfind(")") + 2:].split()
    require(len(fields) > 19, "Incomplete /proc process identity")
    alive = fields[0] not in {"Z", "X"} and fields[19] == expected
    return {"pid": pid, "expected_starttime": expected, "observed_starttime": fields[19],
            "process_state": fields[0], "alive": alive}


def quote_debugfs(value):
    value = str(value)
    require(not any(c in value for c in "\0\n\r"), "Invalid debugfs path")
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


class Auditor:
    def __init__(self, evidence):
        self.evidence, self.commands = evidence, []

    def command(self, label, argv, expected=(0,)):
        started = time.monotonic()
        result = subprocess.run(list(map(str, argv)), capture_output=True, text=True)
        prefix = f"{len(self.commands):03d}-{label}"
        stdout, stderr = self.evidence / (prefix + ".stdout"), self.evidence / (prefix + ".stderr")
        stdout.write_text(result.stdout)
        stderr.write_text(result.stderr)
        record = {"label": label, "argv": list(map(str, argv)), "exit_code": result.returncode,
                  "elapsed_s": time.monotonic() - started, "stdout": stdout.name,
                  "stdout_sha256": sha256(stdout), "stderr": stderr.name, "stderr_sha256": sha256(stderr)}
        self.commands.append(record)
        if expected is not None:
            require(result.returncode in expected, f"{label} failed ({result.returncode}): {result.stderr[-1000:]}")
        return result, record

    def fsck(self, label, image):
        _, record = self.command(label, ["e2fsck", "-f", "-n", image])
        return record

    def debugfs(self, label, image, request):
        return self.command(label, ["debugfs", "-R", request, image])

    def dump(self, label, image, name, destination):
        require(not destination.exists(), f"Refusing to overwrite extracted file: {destination}")
        _, record = self.debugfs(label, image, f"dump -p {quote_debugfs('/' + name)} {quote_debugfs(destination)}")
        require(destination.is_file() and not destination.is_symlink(), f"debugfs did not extract {name}")
        return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--disk", type=Path, help="Retained outer image or detached published copy")
    parser.add_argument("--probe", type=Path, help="Measured home-storage-probe binary")
    parser.add_argument("--work-dir", type=Path, help="New evidence directory; default OUT.evidence")
    parser.add_argument("--offline-copy", action="store_true", help="Require --disk; skip historical process checks for a detached copy")
    args = parser.parse_args()
    require(not args.out.exists(), "Audit result already exists")
    source = json.loads(args.report.read_text())
    require(source["result"] == "passed" and source.get("storage_cleanly_unmounted") is True and
            source.get("cleanup_errors") == [], "Requires successful cleanly unmounted storage run")
    config = source["config"]
    home = config["home_storage_image"]
    require(home["owner"] == "A" and home["readonly"] is False, "Incorrect storage owner/mode")
    generation = source["final_generation"]
    require(1 <= source["arguments"]["cycles"] <= 10 and generation == source["arguments"]["cycles"] * 4,
            "Unexpected final generation")
    expected_image = config["prepared"]["home_storage"]["image"]
    expected_files = expected_image["files"]
    require(set(expected_files) == set(TAGS) | {"fixture", "generation", "journal.log"}, "Unexpected fixture files")
    disk = (args.disk or Path(home["path"])).resolve(strict=True)
    probe = (args.probe or Path(config["assets"]) / "home-storage-probe").resolve(strict=True)
    require(disk.is_file() and probe.is_file(), "Missing outer image or probe")
    shutdown = {}
    if args.offline_copy:
        require(args.disk is not None and disk != Path(home["path"]).resolve(),
                "Offline audit requires a detached disk copy, not the original run's image")
        shutdown = {"mode": "offline-detached-copy", "historical_shutdown_verified": False}
    else:
        shutdown = {"mode": "live-host-stopped-lab", "processes": {role: process_state(vm) for role, vm in config["vms"].items()},
                    "pid_namespace": os.readlink("/proc/self/ns/pid"), "absent_paths": []}
        require(set(shutdown["processes"]) == {"A", "B"} and
                not any(row["alive"] for row in shutdown["processes"].values()), "Owned QEMU still alive")
        # These shared filesystem observations also prevent treating an isolated
        # PID namespace's missing PIDs alone as proof that the host lab stopped.
        for key in ("control_dir", "ephemeral_memory_dir", "cxl_backing"):
            path = config.get(key)
            require(path and not Path(path).exists(), f"Lab stop/cleanup not complete: {key}")
            shutdown["absent_paths"].append(path)
        for vm in config["vms"].values():
            require(not Path(vm["qmp"]).exists(), "Owned QMP endpoint still exists")
    evidence = (args.work_dir or Path(str(args.out) + ".evidence")).resolve()
    evidence.mkdir(parents=True, exist_ok=False)
    auditor = Auditor(evidence)
    result = {"schema_version": 1, "result": "running", "report": str(args.report.resolve()),
              "report_sha256": sha256(args.report), "disk": str(disk), "probe": str(probe),
              "evidence_dir": str(evidence), "shutdown": shutdown, "commands": auditor.commands,
              "scope": "Retained disk after clean guest and host unmount; no host mounts; not power-loss durability",
              "negative_cases": []}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    def save():
        args.out.write_text(json.dumps(result, indent=2) + "\n")
    try:
        result["probe_sha256"] = sha256(probe)
        require(result["probe_sha256"] == config["prepared"]["artifacts"]["home-storage-probe"], "Probe binary differs from measured build")
        outer_before = sha256(disk)
        result["outer"] = {"bytes": disk.stat().st_size, "sha256": outer_before,
                           "initial_sha256": home["initial_sha256"]}
        require(outer_before != home["initial_sha256"], "Writable image did not change")
        result["outer"]["fsck"] = auditor.fsck("outer-fsck", disk)
        inner = evidence / "sandbox.raw"
        auditor.dump("inner-extract", disk, "sandbox.raw", inner)
        require(inner.stat().st_size == expected_image["bytes"], "Guest disk size changed")
        result["inner"] = {"file": inner.name, "bytes": inner.stat().st_size, "sha256": sha256(inner)}
        require(result["inner"]["sha256"] == source["final_image"]["sha256"], "Retained guest disk differs from final host hash")
        result["inner"]["fsck"] = auditor.fsck("inner-fsck", inner)
        stats, stats_record = auditor.debugfs("inner-stats", inner, "stats")
        uuid = re.findall(r"^Filesystem UUID:\s+(\S+)\s*$", stats.stdout, re.M)
        block_size = re.findall(r"^Block size:\s+(\d+)\s*$", stats.stdout, re.M)
        require(uuid == [expected_image["ext4_uuid"]] and len(block_size) == 1, "Guest ext4 UUID/layout changed")
        block_size = int(block_size[0])
        require(block_size == 4096, "Unsupported test ext4 block size")
        result["inner"].update(uuid=uuid[0], block_size=block_size, stats=stats_record)
        listing, _ = auditor.debugfs("inner-root-list", inner, "ls -p /")
        names = [line.split("/")[5] for line in listing.stdout.splitlines() if line.startswith("/")]
        require(len(names) == len(set(names)) and set(names) == set(expected_files) | {".", "..", "lost+found"},
                f"Unexpected guest disk root entries: {names}")
        files = evidence / "files"
        files.mkdir()
        for name in sorted(expected_files):
            auditor.dump("file-extract-" + name, inner, name, files / name)
        result["files"] = {name: {"bytes": (files / name).stat().st_size, "sha256": sha256(files / name)}
                           for name in sorted(expected_files)}
        require((files / "generation").read_bytes() == f"{generation}\n".encode(), "Disk generation mismatch")
        require((files / "journal.log").read_bytes() == "".join(f"generation={i}\n" for i in range(1, generation + 1)).encode(),
                "Disk journal sequence mismatch")
        for name in ("fixture", "payload.bin", "cursor.bin"):
            require(result["files"][name]["sha256"] == expected_files[name]["sha256"], f"Immutable disk file changed: {name}")
        result["generation"], result["journal_lines"] = generation, generation
        print("DISK_AUDIT extracted_clean_filesystems", flush=True)
        probe_run, probe_record = auditor.command("probe-audit", [probe, "audit", files, generation])
        probe_audit = json.loads(probe_run.stdout)
        require(probe_audit.get("ok") is True and probe_audit["generation"] == generation, "C probe rejected disk audit")
        result["probe_audit"] = {"command": probe_record, "receipt": probe_audit}
        result["python_oracle"] = {}
        for name, tag in TAGS.items():
            file_generation = generation if name in {"mutable.bin", "mapped.bin"} else 0
            checked = pattern_file(files / name, tag, file_generation, expected_files[name]["bytes"])
            require(checked["fnv1a64"] == probe_audit[HASH_FIELDS[name]] == source["fresh_boot_audit"]["receipt"][HASH_FIELDS[name]],
                    f"Independent disk checksum mismatch: {name}")
            result["python_oracle"][name] = checked
            print("DISK_AUDIT oracle", name, checked["words"], flush=True)
        result["pattern_words_checked"] = sum(r["words"] for r in result["python_oracle"].values())
        result["pattern_bytes_checked"] = sum(r["bytes"] for r in result["python_oracle"].values())
        save()

        # Mutate real data blocks in independent image copies; only logs and the
        # deterministic mutation recipe survive, so the archive need not store
        # six almost-identical large disks. The retained canonical disk is intact.
        for name in [*TAGS, "journal.log", "generation"]:
            with tempfile.TemporaryDirectory(prefix="negative-", dir=evidence) as temp:
                temp = Path(temp)
                corrupted = temp / "sandbox.raw"
                auditor.command("negative-copy-" + name, ["cp", "--reflink=auto", "--sparse=always", "--", inner, corrupted])
                file_offset = result["files"][name]["bytes"] - (2 if name == "journal.log" else 1)
                if name == "generation":
                    file_offset = 0
                mapping, _ = auditor.debugfs("negative-bmap-" + name, inner,
                    f"bmap {quote_debugfs('/' + name)} {file_offset // block_size}")
                blocks = re.findall(r"^([0-9]+)\s*$", mapping.stdout, re.M)
                require(len(blocks) == 1 and int(blocks[0]) > 0, "No allocated file-data block")
                disk_offset = int(blocks[0]) * block_size + file_offset % block_size
                require(disk_offset < corrupted.stat().st_size, "Mutation outside image")
                with corrupted.open("r+b") as stream:
                    stream.seek(disk_offset)
                    old = stream.read(1)
                    require(len(old) == 1, "Missing mutation byte")
                    new = bytes([old[0] ^ 1])
                    if name == "generation":
                        require(old in [bytes([i]) for i in range(48, 58)], "Generation is not decimal")
                        new = b"2" if old != b"2" else b"3"
                    stream.seek(disk_offset)
                    stream.write(new)
                    stream.flush()
                    os.fsync(stream.fileno())
                case_files = temp / "files"
                case_files.mkdir()
                for other in expected_files:
                    if other != name:
                        os.link(files / other, case_files / other)
                auditor.dump("negative-extract-" + name, corrupted, name, case_files / name)
                require((case_files / name).stat().st_size == result["files"][name]["bytes"], "Mutation unexpectedly changed file size")
                failed, command = auditor.command("negative-probe-" + name,
                    [probe, "audit", case_files, generation], expected=None)
                require(failed.returncode != 0, f"C probe accepted corrupted disk file {name}")
                if name in TAGS:
                    word_index = file_offset // 8
                    with (case_files / name).open("rb") as stream:
                        stream.seek(word_index * 8)
                        actual = struct.unpack("<Q", stream.read(8))[0]
                    g = generation if name in {"mutable.bin", "mapped.bin"} else 0
                    expected_word = mix(TAGS[name] ^ ((g * MULTIPLIER) & MASK) ^ word_index)
                    require(actual != expected_word, "Independent oracle did not reject mutation")
                    oracle = {"word": word_index, "expected": f"{expected_word:016x}", "observed": f"{actual:016x}"}
                else:
                    expected_text = f"{generation}\n" if name == "generation" else "".join(f"generation={i}\n" for i in range(1, generation + 1))
                    require((case_files / name).read_bytes() != expected_text.encode(), "Metadata oracle did not reject mutation")
                    oracle = {"expected_text": expected_text, "observed_hex": (case_files / name).read_bytes().hex()}
                result["negative_cases"].append({"file": name, "result": "rejected", "file_offset": file_offset,
                    "image_offset": disk_offset, "before_byte": old.hex(), "after_byte": new.hex(),
                    "mutated_image_sha256": sha256(corrupted), "mutated_file_sha256": sha256(case_files / name),
                    "probe": command, "python_oracle": oracle, "temporary_copy_removed": True})
            print("DISK_AUDIT negative", name, flush=True)
            save()
        require(sha256(disk) == outer_before and sha256(inner) == result["inner"]["sha256"], "Read-only audit changed retained image")
        for name, record in result["files"].items():
            require(sha256(files / name) == record["sha256"], "Negative test changed baseline file")
        result.update(result="passed", original_images_unchanged=True,
                      completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      archive_note="Keep one canonical outer disk plus this script, measured probe, report and logs; extraction and corruption cases are reproducible without archiving duplicate files/images.")
    except BaseException as error:
        result.update(result="failed", error=repr(error))
        raise
    finally:
        save()
    print(json.dumps({"result": result["result"], "out": str(args.out), "pattern_words_checked": result["pattern_words_checked"],
                      "negative_cases": len(result["negative_cases"])}), flush=True)


if __name__ == "__main__":
    main()
