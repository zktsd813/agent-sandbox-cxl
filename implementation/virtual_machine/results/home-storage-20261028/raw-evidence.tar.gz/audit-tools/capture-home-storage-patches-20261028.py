#!/usr/bin/env python3
import argparse,hashlib,json,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('reports',nargs='+',type=Path);a=p.parse_args()
rows=[]
for report in a.reports:
 r=json.loads(report.read_text());assert r['result']=='passed'
 expected=r['config']['source_patches'];assert expected
 dst=report.parent/'measured-patches';dst.mkdir(exist_ok=True)
 records={}
 for name,digest in expected.items():
  assert Path(name).name==name
  src=a.source_dir/name;data=src.read_bytes();assert hashlib.sha256(data).hexdigest()==digest,(report,name)
  if (dst/name).exists():assert (dst/name).read_bytes()==data
  else:shutil.copy2(src,dst/name)
  records[name]=digest
 rows.append({'report':str(report),'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'files':records})
a.out.write_text(json.dumps({'result':'passed','scope':'Post-run source capture matched hashes recorded at lab start; report bytes unchanged','runs':rows},indent=2)+'\n')
print(json.dumps({'result':'passed','runs':len(rows)}))
