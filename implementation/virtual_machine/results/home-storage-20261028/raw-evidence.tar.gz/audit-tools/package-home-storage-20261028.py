#!/usr/bin/env python3
"""Package completed owned experiments; never execute while the VM matrix runs."""
import argparse,hashlib,json,shutil,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--trace-report',type=Path,required=True);a=p.parse_args()
repo=Path('/tmp/agent-sandbox-cxl-microvm-main-20261023');base=repo/'implementation/virtual_machine'
out=base/'results/home-storage-20261028';stage=Path('/tmp/home-storage-evidence-20261028');stage.mkdir(exist_ok=False)
home=base/'.local/runs/20261028T045018Z-i3y0_2u5/home-storage-1793163019326669414/report.json'
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def copy(src,dst):
 src=Path(src);dst=Path(dst);assert src.is_file() and not src.is_symlink(),src
 dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():assert sha(src)==sha(dst),dst
 else:shutil.copy2(src,dst)
def tree(src,dst):
 for f in sorted(Path(src).rglob('*')):
  if f.is_file():copy(f,Path(dst)/f.relative_to(src))
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def patches(config,destination):
 for name,expected in config['source_patches'].items():
  assert sha(base/name)==expected,name
  copy(base/name,destination/'measured-patches'/name)
hr=read(home);tr=read(a.trace_report)
assert hr['result']==tr['result']=='passed'
assert hr['storage_cleanly_unmounted'] and not hr['cleanup_errors'] and not tr['cleanup_errors']
assert len(hr['transitions'])==12 and len(tr['trials'])==24
for name,path in [('home',home),('trace',a.trace_report)]:
 tree(path.parent,stage/name)
 patches(read(path)['config'],stage/name)
 for f in ('run.json','report.json','vm-a.serial.log','vm-b.serial.log'):
  src=path.parent.parent/f
  if src.is_file():copy(src,stage/'labs'/name/f)
for case in ('direct-block','direct-two-vcpu','direct-baseline'):
 src=Path('/tmp/compat-safe-'+case+'-20261028-v2');r=read(src/'report.json');assert r['result']=='passed'
 tree(src,stage/'direct'/case)
 patches(r['config'],stage/'direct'/case)
 if r.get('baseline_report'):tree(Path(r['baseline_report']).parent,stage/'direct'/case/'baseline')
 for f in ('run.json','vm-a.serial.log','vm-b.serial.log'):
  src=Path(r['run'])/f
  if src.is_file():copy(src,stage/'labs'/case/f)
# Preserve failed/pilot run evidence without duplicating their generated disks.
for name,path in [
 ('home-v1',base/'.local/runs/20261028T042852Z-ppfz5epq/home-storage-1793161733863739834/report.json'),
 ('home-smoke',base/'.local/runs/20261028T042345Z-7ey10qvo/home-storage-1793161426350807358/report.json'),
 ('home-repack-permissions',base/'.local/runs/20261028T044711Z-modlz0p_/home-storage-1793162831995205656/report.json'),
 ('trace-v1-smoke',base/'.local/runs/20261028T043533Z-2wqapmsf/trace-1793162145562370636/report.json')]:
 tree(path.parent,stage/'pilots'/name)
 for f in ('run.json','vm-a.serial.log','vm-b.serial.log'):
  src=path.parent.parent/f
  if src.is_file():copy(src,stage/'pilots'/name/'lab'/f)
# Supplementary unit tests and exact failure/correction records.
for name in ('home-storage-publication-inventory-20261028.json','fc-storage-publication-inventory-20261028.json'):
 inventory=read('/tmp/'+name);copy('/tmp/'+name,stage/'inventories'/name)
 if 'groups' in inventory:
  for group in inventory['groups']:
   for f in group['files']:
    src=Path(f['path']);assert sha(src)==f['sha256'],src
    copy(src,stage/'supplementary'/src.relative_to('/tmp'))
 else:
  for f in inventory['entries']:
   if not f.get('required'):continue
   src=Path(f['source'])
   if f.get('sha256'):assert sha(src)==f['sha256'],src
   copy(src,stage/f['archive_path'])
# Runnable audit tools and production helper used for detached disk verification.
for name in ('verify_home_storage.py','verify_trace_results.py'):
 copy(base/name,stage/'audit-tools'/name)
for name in ('audit-safe-direct.py','audit-home-storage-disk.py','negative_trace_audit.py','audit-home-storage-cleanup-20261028.py',
             'repack-storage-firecracker-20261028.py','check-storage-repack-20261028.py','package-home-storage-20261028.py',
             'replay-home-storage-publication-20261028.py','summarize-home-storage-20261028.py','capture-home-storage-patches-20261028.py'):
 copy('/tmp/'+name,stage/'audit-tools'/name)
for name,src in [('home-storage-probe','/tmp/home-storage-probe'),('ram-transfer','/tmp/ram-transfer-20261028'),('shared-probe','/tmp/state-mailbox-probe')]:
 copy(src,stage/'tools'/name)
small_names=[
 'ram-transfer-build-20261028.json','ram-transfer-tests-20261028.json','ram-transfer-cli-tests-20261028.json',
 'rl-tmpfs-prior-work-20261028.json','storage-repack-final-check-20261028.json','storage-repack-mode-regression-20261028.json',
 'home-assets-v4-repack.json','trace-assets-v3-repack.json','repack-storage-firecracker-before-mode-fix-20261028.py',
 'run-home-storage-20261028.py','run-trace-home-20261028.py','run-safe-direct-20261028.py',
 'home-storage-final-20261028.log','home-storage-final-api-20261028.log','home-storage-final-api-r2-20261028.log',
 'trace-home-final-20261028.log','safe-direct-v2-20261028.log','home-storage-final-api-disk-audit.log',
 'home-storage-final-api-disk-archive.json','home-storage-final-source-audit-20261028.json',
 'home-storage-cleanup-inputs-20261028.json','home-storage-source-patches-capture-20261028.json',
 'trace-home-final-source-audit-20261028.json','trace-home-final-negative-20261028.log']
for name in small_names:copy('/tmp/'+name,stage/'supplementary'/name)
for f in Path('/tmp/home-storage-final-api-disk-audit.json.evidence').iterdir():
 if f.is_file() and f.suffix in ('.stdout','.stderr'):copy(f,stage/'disk-audit-raw'/f.name)
primary={
 'home-report.json':home,'trace-report.json':a.trace_report,
 'home-audit.json':Path('/tmp/home-storage-final-api-audit-20261028.json'),
 'disk-audit.json':Path('/tmp/home-storage-final-api-disk-audit.json'),
 'direct-audit.json':Path('/tmp/audit-safe-direct-20261028-v2.json'),
 'trace-audit.json':Path('/tmp/trace-home-final-audit-20261028.json'),
 'trace-negative-tests.json':Path('/tmp/trace-home-final-negative-20261028.json'),
 'cleanup.json':Path('/tmp/home-storage-final-cleanup-20261028.json'),
 'research.json':Path('/tmp/rl-tmpfs-prior-work-20261028.json'),
 'build.json':Path('/tmp/fc-storage-safety-build.json'),
 'disk-archive.json':Path('/tmp/home-storage-final-api-disk-archive.json')}
for name,src in primary.items():
 copy(src,out/name);copy(src,stage/'audits'/name)
for asset in ('assets-home-storage-api-v4-20261028','assets-trace-home-api-v3-20261028','assets-guards-storage-api-v2-20261028'):
 copy(base/'.local'/asset/'manifest.json',stage/'asset-manifests'/asset/'manifest.json')
# Compare all archived bytes after fresh extraction in a separate replay step.
manifest={str(f.relative_to(stage)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(stage.rglob('*')) if f.is_file()}
save(stage/'evidence-manifest.json',{'schema_version':1,'files':manifest,'excluded':'Prepared images, full RAM payloads, duplicate disk extractions. Canonical outer disk is separate.'})
archive=out/'raw-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for f in sorted(stage.rglob('*')):
  if f.is_file():tar.add(f,arcname=str(f.relative_to(stage)),recursive=False)
disk_record=read('/tmp/home-storage-final-api-disk-archive.json')
assert sha('/tmp/home-storage-final-api-outer.raw.gz')==disk_record['archive_sha256']
assert Path('/tmp/home-storage-final-api-outer.raw.gz').stat().st_size==disk_record['archive_bytes']
assert disk_record['uncompressed_sha256']==read('/tmp/home-storage-final-api-disk-audit.json')['outer']['sha256']
copy('/tmp/home-storage-final-api-outer.raw.gz',out/'final-home-storage.raw.gz')
files={f.name:{'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(out.iterdir()) if f.is_file() and f.name not in ('README.md','manifest.json','summary.json')}
save(out/'manifest.json',{'schema_version':1,'files':files,'evidence_files':len(manifest),'raw_evidence_manifest_sha256':sha(stage/'evidence-manifest.json')})
print(json.dumps({'stage':str(stage),'result_dir':str(out),'archive_bytes':archive.stat().st_size,'evidence_files':len(manifest)}))
