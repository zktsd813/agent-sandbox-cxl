#!/usr/bin/env python3
"""Fresh-extraction, read-only audit replay; run after all runtime trials stop."""
import gzip,hashlib,json,shutil,subprocess,tarfile,time
from pathlib import Path
repo=Path('/tmp/agent-sandbox-cxl-microvm-main-20261023')
out=repo/'implementation/virtual_machine/results/home-storage-20261028'
dest=Path('/tmp/home-storage-offline-replay-20261028');dest.mkdir(exist_ok=False)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
 return h.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
m=read(out/'manifest.json')
for name,r in m['files'].items():assert sha(out/name)==r['sha256'] and (out/name).stat().st_size==r['bytes'],name
with tarfile.open(out/'raw-evidence.tar.gz') as tar:
 for member in tar.getmembers():
  p=Path(member.name)
  assert member.isfile() and not p.is_absolute() and '..' not in p.parts,member.name
 tar.extractall(dest)
e=read(dest/'evidence-manifest.json')
assert sha(dest/'evidence-manifest.json')==m['raw_evidence_manifest_sha256']
for name,r in e['files'].items():assert sha(dest/name)==r['sha256'] and (dest/name).stat().st_size==r['bytes'],name
assert {str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file()}==set(e['files'])|{'evidence-manifest.json'}
commands=[]
def run(label,args):
 log=dest/(label+'.log');start=time.monotonic()
 with log.open('w') as stream:r=subprocess.run(list(map(str,args)),stdout=stream,stderr=subprocess.STDOUT)
 record={'label':label,'argv':list(map(str,args)),'exit_code':r.returncode,'elapsed_s':time.monotonic()-start,'log':str(log),'log_sha256':sha(log)}
 commands.append(record);assert r.returncode==0,record
 print(label,'passed',flush=True)
run('home-offline',['python3',dest/'audit-tools/verify_home_storage.py',dest/'home/report.json','--full-patterns','--negative-tests','--out',dest/'home-offline.json'])
run('trace-offline',['python3',dest/'audit-tools/verify_trace_results.py',dest/'trace/report.json','--formal','--json-out',dest/'trace-offline.json'])
run('direct-offline',['python3',dest/'audit-tools/audit-safe-direct.py',*[dest/'direct'/n for n in ('direct-block','direct-two-vcpu','direct-baseline')],'--out',dest/'direct-offline.json'])
raw=dest/'home-storage.raw'
with gzip.open(out/'final-home-storage.raw.gz','rb') as src,raw.open('xb') as f:shutil.copyfileobj(src,f,1024*1024)
disk=read(out/'disk-archive.json');assert sha(raw)==disk['uncompressed_sha256'] and raw.stat().st_size==disk['uncompressed_bytes']
run('disk-offline',['python3',dest/'audit-tools/audit-home-storage-disk.py','--report',dest/'home/report.json','--disk',raw,'--probe',dest/'tools/home-storage-probe','--offline-copy','--out',dest/'disk-offline.json'])
result={'schema_version':1,'result':'passed','evidence_files_sha256_checked':len(e['files']),'published_files_sha256_checked':len(m['files']),
        'raw_evidence_sha256':m['files']['raw-evidence.tar.gz']['sha256'],'disk_archive_sha256':m['files']['final-home-storage.raw.gz']['sha256'],
        'commands':commands,'results':{n:read(dest/(n+'-offline.json')) for n in ('home','trace','direct','disk')},
        'scope':'Fresh detached extraction, no VMs; artifact builds/large prepared images optional and not rechecked offline; final retained disk fully audited.'}
save(out/'packaging-audit.json',result)
# Publish compact replay logs/JSON as a separate post-package evidence artifact.
archive=out/'offline-audit-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for n in ('home','trace','direct','disk'):
  for suffix in ('.log','.json'):tar.add(dest/(n+'-offline'+suffix),arcname=n+'-offline'+suffix,recursive=False)
 for f in sorted((dest/'disk-offline.json.evidence').iterdir()):
  if f.is_file() and f.suffix in ('.stdout','.stderr'):tar.add(f,arcname='disk-command-logs/'+f.name,recursive=False)
for n in ('packaging-audit.json','offline-audit-evidence.tar.gz'):
 m['files'][n]={'bytes':(out/n).stat().st_size,'sha256':sha(out/n)}
save(out/'manifest.json',m)
print(json.dumps({'result':'passed','evidence_files':len(e['files']),'out':str(out/'packaging-audit.json')}))
