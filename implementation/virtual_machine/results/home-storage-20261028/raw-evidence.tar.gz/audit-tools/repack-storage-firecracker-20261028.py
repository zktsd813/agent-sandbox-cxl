import argparse,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
sys.path.insert(0,'/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine')
import lab
p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('destination',type=Path);p.add_argument('firecracker',type=Path);a=p.parse_args()
src=a.source.resolve(strict=True);dst=a.destination.resolve();fc=a.firecracker.resolve(strict=True)
assert not dst.exists()
m=json.loads((src/'manifest.json').read_text());old_manifest_sha=lab.sha256(src/'manifest.json')
for name,sha in m['artifacts'].items(): assert lab.sha256(src/name)==sha,name
subprocess.run(['cp','-a','--reflink=auto','--sparse=always','--',str(src),str(dst)],check=True)
with tempfile.TemporaryDirectory(prefix='storage-repack-',dir=dst) as tmp:
 root=Path(tmp)
 # cpio extraction leaves the pre-existing TemporaryDirectory root at 0700.
 # Preserve the source archive root so privilege-dropped daemons can traverse /.
 with (src/'l1-initramfs.cpio').open('rb') as archive:
  header=archive.read(110);name=archive.read(int(header[94:102],16))
 assert header[:6]==b'070701' and name==b'.\0'
 root.chmod(int(header[14:22],16) & 0o7777)
 with (src/'l1-initramfs.cpio').open('rb') as stream:
  subprocess.run(['cpio','-id','--quiet','--no-absolute-filenames'],cwd=root,stdin=stream,check=True)
 subprocess.run(['cp','--',str(fc),str(root/'lab/firecracker')],check=True)
 lab.pack_initramfs(root,dst/'l1-initramfs.cpio')
if (dst/'firecracker').exists(): subprocess.run(['cp','--',str(fc),str(dst/'firecracker')],check=True)
m['inputs']['firecracker']={'path':str(fc),'sha256':lab.sha256(fc)}
m['firecracker_version']=subprocess.check_output([str(fc),'--version'],stderr=subprocess.STDOUT,text=True)
m['repacked_from']={'assets':str(src),'manifest_sha256':old_manifest_sha,'purpose':'replace Firecracker with tested storage/API safety build','script_sha256':lab.sha256(Path(__file__))}
m['artifacts']={name:lab.sha256(dst/name) for name in m['artifacts']}
lab.save_json(dst/'manifest.json',m)
print(json.dumps({'assets':str(dst),'firecracker_sha256':m['inputs']['firecracker']['sha256'],'source_manifest_sha256':old_manifest_sha,'manifest_sha256':lab.sha256(dst/'manifest.json')}))
