import hashlib,json
from pathlib import Path
base=Path('/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine/.local')
def read(path):
 d=path.read_bytes();i=0;r={}
 while d[i:i+6]==b'070701':
  h=[int(d[i+6+k*8:i+14+k*8],16) for k in range(13)];i+=110;n=d[i:i+h[11]-1].decode();i=(i+h[11]+3)&~3;data=d[i:i+h[6]];i=(i+h[6]+3)&~3
  if n=='TRAILER!!!':break
  r[n]={'mode':oct(h[1]),'uid':h[2],'gid':h[3],'nlink':h[4],'bytes':h[6],'sha256':hashlib.sha256(data).hexdigest()}
 return r
rows=[]
for old,new in [('assets-home-storage-v2-20261028','assets-home-storage-api-v4-20261028'),('assets-trace-home-v1-20261028','assets-trace-home-api-v3-20261028')]:
 a=read(base/old/'l1-initramfs.cpio');b=read(base/new/'l1-initramfs.cpio');keys=sorted(a.keys()|b.keys());differences=[k for k in keys if a.get(k)!=b.get(k)]
 assert differences==['lab/firecracker'],differences
 assert b['lab/firecracker']['sha256']=='4dae92f73528627231d1a15c8a4c289e6b3b3bacb2ad4fa18c2f988ab2d8480c'
 rows.append({'source':old,'destination':new,'entries':len(a),'changed_entries':differences,'root_mode':b['.']['mode'],'binary_sha256':b['lab/firecracker']['sha256']})
print(json.dumps({'result':'passed','comparisons':rows},indent=2))
