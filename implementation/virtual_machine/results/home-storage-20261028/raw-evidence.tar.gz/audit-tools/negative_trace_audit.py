#!/usr/bin/env python3
"""Exercise the trace auditor against altered copies of completed real evidence.

Run after a successful experiment, e.g.:
  python3 negative_trace_audit.py --report REPORT --evidence-dir EVIDENCE \
    --verifier implementation/virtual_machine/verify_trace_results.py --json-out OUT
The original report and evidence are only read. Each mutation gets a separate
copy; the checks that alter content also refresh outer checksums where needed.
"""
import argparse
import base64
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import shutil
import statistics
import tarfile
import tempfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def summary(report):
    groups = {}
    for trial in report['trials']:
        groups.setdefault((trial['trace'], trial['backend'], trial['cache_mode']), []).append(trial)
    rows = []
    for (trace, backend, mode), trials in sorted(groups.items()):
        row = dict(trace=trace, backend=backend, cache_mode=mode, n=len(trials))
        for key in ('guest_duration_s', 'destination_duration_s', 'nfs_read_calls', 'nfs_received_bytes'):
            values = [trial[key] for trial in trials]
            row[key] = dict(median=statistics.median(values), min=min(values), max=max(values))
        rows.append(row)
    report['summary'] = rows


def repack(verifier, directory, trial, files, changed_ends=None):
    """Keep archive framing/log/report checksums consistent with changed payloads."""
    changed_ends = changed_ends or {}
    for index, end in changed_ends.items():
        files[f'results/{index:03d}.json'] = (json.dumps(end, separators=(',', ':')) + '\n').encode()
        trial['commands'][index].update(end)
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w:gz') as archive:
        for name, data in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(data), 0o644
            archive.addfile(member, io.BytesIO(data))
    data = stream.getvalue()
    (directory / trial['guest_archive']).write_bytes(data)
    trial['guest_archive_sha256'] = sha(data)
    for item in trial['logs']:
        path = directory / item['path']
        text = path.read_bytes().decode()
        lines = []
        for line in text.splitlines(keepends=True):
            if line.startswith('{"event":'):
                row = json.loads(line)
                if row['event'] == 'trace_start' and row['index'] in changed_ends:
                    row['start_s'] = changed_ends[row['index']]['start_s']
                    line = json.dumps(row, separators=(',', ':')) + '\n'
                elif row['event'] == 'trace_end' and row['index'] in changed_ends:
                    row = changed_ends[row['index']]
                    line = json.dumps(row, separators=(',', ':')) + '\n'
                elif row['event'] == 'trace_export':
                    row.update(bytes=len(data), sha256=sha(data))
                    line = json.dumps(row, separators=(',', ':')) + '\n'
            lines.append(line)
        text = ''.join(lines)
        if 'TRACE_EXPORT_BEGIN ' in text:
            token = trial['id'] + '_export'
            encoded = base64.b64encode(data).decode()
            framed = (f'TRACE_EXPORT_BEGIN {token} {len(data)} {sha(data)}\n' +
                      '\n'.join(encoded[offset:offset + 76] for offset in range(0, len(encoded), 76)) +
                      f'\nTRACE_EXPORT_END {token}')
            pattern = rf'TRACE_EXPORT_BEGIN {re.escape(token)} [0-9]+ [0-9a-f]{{64}}\r?\n.*?TRACE_EXPORT_END {re.escape(token)}'
            text, count = re.subn(pattern, lambda _: framed, text, flags=re.S)
            assert count == 1
        raw = text.encode()
        path.write_bytes(raw)
        item['integrity'].update(bytes=len(raw), sha256=sha(raw))


RAM_CASES = (
    'ram_zero_copy_claim', 'ram_wrong_return_tier', 'ram_short_copy_with_matching_receipt',
    'ram_partial_verification_with_matching_receipt', 'ram_fnv_mismatch_with_matching_receipt',
    'ram_reserved_prefix_with_matching_receipt', 'ram_missing_poison',
    'ram_wrong_poison_with_matching_receipt', 'ram_duplicate_native_receipt',
    'ram_source_pid_forgery', 'ram_source_pid_and_fence_forgery',
    'ram_return_dax_vma_with_matching_raw', 'ram_short_vma_with_matching_raw',
    'ram_private_cxl_vma_with_matching_raw', 'ram_initial_owner_forgery',
    'ram_nonlocal_file_mount_with_matching_raw', 'ram_wrong_native_file_directory',
    'ram_helper_source_with_refreshed_sha', 'ram_lifecycle_downgrade_consistent_reports',
)


def rewrite_native_receipt(directory, evidence, prefix):
    path = directory / evidence['file']
    lines = path.read_text().splitlines()
    assert sum(line.startswith(prefix) for line in lines) == 1
    path.write_text('\n'.join(prefix + json.dumps(evidence['receipt']) if line.startswith(prefix) else line
                              for line in lines) + '\n')


def rewrite_ram_maps(directory, evidence):
    """Forge raw maps consistently too, so rejection tests semantics, not a checksum."""
    text = f"RAM_MAP_OWNER {evidence['owner_pid']} {evidence['owner_starttime']}\n"
    text += f"RAM_RUN_MOUNT {evidence['run_mount']}\n"
    for row in evidence['mappings']:
        text += (f"{row['start']:x}-{row['end']:x} {row['permissions']} {row['offset']:08x} "
                 f"00:00 0 {row['path']}\n")
    (directory / evidence['file']).write_text(text)


def mutate_ram_case(name, report, trial, directory):
    """Mutate only a copy of real completed evidence; return whether to audit all trials."""
    outward, home = trial['handoffs']
    copy_cases = {
        'ram_short_copy_with_matching_receipt': (outward, 'import', 'copied_bytes', 4096),
        'ram_partial_verification_with_matching_receipt': (home, 'export', 'verified_bytes', 4096),
        'ram_fnv_mismatch_with_matching_receipt': (outward, 'import', 'destination_fnv1a64',
            '0000000000000000' if outward['ram_operations']['import']['receipt']['source_fnv1a64'] != '0000000000000000'
            else 'ffffffffffffffff'),
        'ram_reserved_prefix_with_matching_receipt': (outward, 'import', 'dax_offset', 1048576),
        'ram_wrong_poison_with_matching_receipt': (home, 'poison', 'poison_byte', 0),
    }
    if name in copy_cases:
        handoff, operation, key, value = copy_cases[name]
        evidence = handoff['ram_operations'][operation]
        evidence['receipt'][key] = value
        rewrite_native_receipt(directory, evidence, 'RAM_TRANSFER_JSON ')
    elif name == 'ram_zero_copy_claim':
        outward['ram_transfer_bytes'] = 0
    elif name == 'ram_wrong_return_tier':
        home['destination_ram_tier'] = 'cxl'
    elif name == 'ram_missing_poison':
        home['ram_operations'].pop('poison')
    elif name == 'ram_duplicate_native_receipt':
        evidence = outward['ram_operations']['import']
        path = directory / evidence['file']
        path.write_text(path.read_text().rstrip('\r\n') + '\nRAM_TRANSFER_JSON ' + json.dumps(evidence['receipt']) + '\n')
    elif name in ('ram_source_pid_forgery', 'ram_source_pid_and_fence_forgery'):
        evidence = outward['ram_mappings']['source']
        evidence['owner_pid'] += 10000
        rewrite_ram_maps(directory, evidence)
        if name == 'ram_source_pid_and_fence_forgery':
            raw, count = re.subn(r'(?m)^FENCED [0-9]+ ([0-9]+)',
                lambda match: f"FENCED {evidence['owner_pid']} {match[1]}", outward['source_fence'])
            assert count == 1
            outward['source_fence'] = raw
            (directory / outward['fence_file']).write_text(raw)
    elif name in ('ram_return_dax_vma_with_matching_raw', 'ram_short_vma_with_matching_raw',
                  'ram_private_cxl_vma_with_matching_raw'):
        handoff = home if name == 'ram_return_dax_vma_with_matching_raw' else outward
        evidence = handoff['ram_mappings']['destination']
        wanted_path = evidence['memory_path'] or '/dev/dax0.0'
        selected = [row for row in evidence['mappings'] if row['path'] == wanted_path]
        assert len(selected) == 1
        if name == 'ram_return_dax_vma_with_matching_raw':
            selected[0].update(path='/dev/dax0.0', permissions='rw-s', offset=2097152)
        elif name == 'ram_short_vma_with_matching_raw':
            selected[0]['end'] -= 4096
        else:
            selected[0]['permissions'] = 'rw-p'
        rewrite_ram_maps(directory, evidence)
    elif name == 'ram_initial_owner_forgery':
        evidence = trial['initial_ram_mapping']
        evidence['owner_pid'] += 10000
        rewrite_ram_maps(directory, evidence)
    elif name == 'ram_nonlocal_file_mount_with_matching_raw':
        evidence = home['ram_mappings']['destination']
        evidence['run_mount'] = '172.30.0.1:/memory /run nfs rw,vers=3 0 0'
        rewrite_ram_maps(directory, evidence)
    elif name == 'ram_wrong_native_file_directory':
        evidence = home['ram_operations']['export']
        old = evidence['memory_file']
        suffix = '0000000000000000' if '/trace-0000000000000000/' not in old else 'ffffffffffffffff'
        evidence['memory_file'] = re.sub(r'/trace-[0-9a-f]{16}/', f'/trace-{suffix}/', old)
        assert evidence['memory_file'] != old
    elif name == 'ram_helper_source_with_refreshed_sha':
        path = directory / 'measured-sources' / 'ram_transfer.c'
        changed = path.read_bytes() + b'\n/* forged prepared RAM helper source */\n'
        path.write_bytes(changed)
        report['runtime_sources']['ram_transfer.c'] = sha(changed)
        return True
    elif name == 'ram_lifecycle_downgrade_consistent_reports':
        report['arguments']['ram_lifecycle'] = 'shared-cxl'
        for row in report['trials']:
            row['ram_lifecycle'] = 'shared-cxl'
            row.pop('initial_ram_mapping')
            for handoff in row['handoffs']:
                handoff['ram_transfer_bytes'] = 0
                for key in ('ram_lifecycle', 'source_ram_tier', 'destination_ram_tier', 'ram_operations', 'ram_mappings'):
                    handoff.pop(key)
        return True
    else:
        raise AssertionError(f'Unknown RAM mutation: {name}')
    return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--evidence-dir', type=Path)
    parser.add_argument('--verifier', type=Path, default=Path('implementation/virtual_machine/verify_trace_results.py'))
    parser.add_argument('--json-out', type=Path, required=True)
    options = parser.parse_args()
    evidence = options.evidence_dir or options.report.parent
    spec = importlib.util.spec_from_file_location('independent_trace_verifier', options.verifier)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    original = json.loads(options.report.read_text())
    manifest = json.loads((evidence / 'manifest.json').read_text())
    audit_args = argparse.Namespace(report=options.report, evidence_dir=evidence, source_dir=None,
                                    manifest=None, formal=False, artifacts=False, assets_dir=None, patch_dir=None, json_out=None)
    with contextlib.redirect_stdout(io.StringIO()) as output:
        assert verifier.audit(audit_args) == 0
    baseline = json.loads(output.getvalue())
    outcomes = []
    cases = ('report_counter_and_summary', 'raw_nfs_counter', 'guest_stdout_with_outer_hashes',
             'final_submission_with_all_hashes', 'test_summary_with_all_hashes',
             'handoff_clock_rewind_with_consistent_timestamps', 'missing_command', 'duplicate_command',
             'fd_position_report_only', 'source_fence_consistent_receipt', 'handoff_mode_direct')
    first = original['trials'][0]
    if any(t['trace'] == first['trace'] and t['backend'] == first['backend'] for t in original['trials'][1:]):
        cases += ('reused_trial_evidence',)
    if 'backend_mount_file' in first:
        cases += ('duplicate_backend_mount',)
    if original['arguments'].get('state_transport') == 'dax-mailbox':
        cases += ('mailbox_destination_with_refreshed_sha', 'mailbox_hash_with_matching_receipts',
                  'mailbox_foreign_nonce_with_matching_receipt', 'mailbox_foreign_round_with_matching_receipt',
                  'mailbox_duplicate_native_receipt', 'native_api_failed_response_with_matching_receipt',
                  'native_helper_source_with_refreshed_sha', 'reused_mailbox_trial_nonce')
    if original['arguments'].get('ram_lifecycle') == 'home-roundtrip':
        cases += RAM_CASES
    with tempfile.TemporaryDirectory(prefix='trace-audit-negative-') as temporary:
        root = Path(temporary)
        for name in cases:
            directory = root / name
            shutil.copytree(evidence, directory)
            report = copy.deepcopy(original)
            trial = report['trials'][0]
            plan = manifest['traces'][trial['trace']]
            trace = verifier.original_trace(directory / 'traces' / (trial['trace'] + '.traj.json'))
            full_audit = False
            if name == 'report_counter_and_summary':
                trial['commands'][0]['network_delta']['nfs_read_calls'] += 1
                trial['commands'][0]['network_delta']['mount_read_ops'] += 1
                trial['commands'][0]['network_delta']['mount_read_received_bytes'] += 100
                trial['nfs_read_calls'] += 1
                trial['nfs_received_bytes'] += 100
                if 'trial_network_delta' in trial:
                    trial['trial_network_delta']['nfs_read_calls'] += 1
                    trial['trial_network_delta']['mount_read_ops'] += 1
                    trial['trial_network_delta']['mount_read_received_bytes'] += 100
                summary(report)
                full_audit = True
            elif name == 'raw_nfs_counter':
                path = directory / trial['commands'][0]['counter_after'] / 'nfs.txt'
                rows = path.read_text().splitlines()
                for i, line in enumerate(rows):
                    if line.startswith('proc3 '):
                        fields = line.split()
                        fields[8] = str(int(fields[8]) + 1)
                        rows[i] = ' '.join(fields)
                path.write_text('\n'.join(rows) + '\n')
            elif name == 'guest_stdout_with_outer_hashes':
                files = verifier.archive_files(directory / trial['guest_archive'])
                files['results/000.out'] += b'\nTAMPERED_STDOUT\n'
                repack(verifier, directory, trial, files)
            elif name == 'final_submission_with_all_hashes':
                files = verifier.archive_files(directory / trial['guest_archive'])
                index = len(trial['commands']) - 1
                prefix = f'results/{index:03d}'
                files[prefix + '.out'] += b'\nTAMPERED_FINAL_PATCH\n'
                end = json.loads(files[prefix + '.json'])
                end['output_sha256'] = sha(files[prefix + '.out'])
                state = files['results/state'].decode().split()
                state[-1] = end['output_sha256']
                files['results/state'] = (' '.join(state) + '\n').encode()
                repack(verifier, directory, trial, files, {index: end})
            elif name == 'test_summary_with_all_hashes':
                files = verifier.archive_files(directory / trial['guest_archive'])
                selected = next(command for command in trace['commands'] if command['source_output'] is not None and
                                verifier.test_summary(command['command'], command['source_output']) is not None)
                index = selected['index']
                prefix = f'results/{index:03d}'
                text = files[prefix + '.out'].decode()
                kind = verifier.test_summary(selected['command'], selected['source_output'])['kind']
                if kind == 'go':
                    text, count = re.subn(r'(?m)^ok([ \t]+)', lambda m: 'FAIL' + m[1], text, count=1)
                elif kind == 'phpunit':
                    text, count = re.subn(r'Tests: ([0-9]+)', lambda m: 'Tests: ' + str(int(m[1]) + 1), text, count=1)
                else:
                    text, count = re.subn(r'(?m)^([0-9]+) tests passed$', lambda m: str(int(m[1]) + 1) + ' tests passed', text, count=1)
                assert count == 1
                files[prefix + '.out'] = text.encode()
                end = json.loads(files[prefix + '.json'])
                end['output_sha256'] = sha(files[prefix + '.out'])
                repack(verifier, directory, trial, files, {index: end})
            elif name == 'handoff_clock_rewind_with_consistent_timestamps':
                files = verifier.archive_files(directory / trial['guest_archive'])
                index = plan['handoff_before']
                end = json.loads(files[f'results/{index:03d}.json'])
                previous = json.loads(files[f'results/{index-1:03d}.json'])
                duration = end['end_s'] - end['start_s']
                end['start_s'] = round(previous['end_s'] - 0.02, 2)
                end['end_s'] = round(end['start_s'] + duration, 2)
                repack(verifier, directory, trial, files, {index: end})
            elif name == 'missing_command':
                trial['commands'].pop(1)
            elif name == 'duplicate_command':
                trial['commands'][1] = copy.deepcopy(trial['commands'][0])
            elif name == 'fd_position_report_only':
                trial['handoffs'][0]['after_identity']['fd_position'] += 1
            elif name == 'duplicate_backend_mount':
                path = directory / trial['backend_mount_file']
                text = path.read_text()
                mount = next(line for line in text.splitlines() if len(line.split()) == 6 and line.split()[1] == '/disk')
                assert text.count(mount) == 1
                path.write_text(text.replace(mount, mount + '\n' + mount, 1))
            elif name == 'reused_trial_evidence':
                target = next(i for i, candidate in enumerate(report['trials'])
                              if i > 0 and candidate['trace'] == trial['trace'] and candidate['backend'] == trial['backend'])
                identity = {key: report['trials'][target][key] for key in ('id', 'cycle', 'backend', 'cache_mode')}
                report['trials'][target] = copy.deepcopy(trial)
                report['trials'][target].update(identity)
                summary(report)
                full_audit = True
            elif name == 'source_fence_consistent_receipt':
                handoff = trial['handoffs'][0]
                receipt = handoff['source_fence']
                expected = int(re.findall(r'^FENCED [0-9]+ ([0-9]+)$', receipt.replace('\r', ''), re.M)[0])
                replacement = f'FENCE_STATE Z {expected + 1}'
                receipt, count = re.subn(r'(?m)^FENCE_STATE [^\r\n]+', replacement, receipt)
                assert count == 1
                handoff['source_fence'] = receipt
                (directory / handoff['fence_file']).write_bytes(receipt.encode())
            elif name == 'handoff_mode_direct':
                trial['handoffs'][0]['handoff_mode'] = 'direct'
            elif name == 'mailbox_destination_with_refreshed_sha':
                handoff = trial['handoffs'][0]
                path = directory / handoff['destination_state_file']
                changed = bytearray(path.read_bytes())
                changed[len(changed) // 2] ^= 1
                path.write_bytes(changed)
                handoff['destination_state_integrity']['sha256'] = sha(changed)
            elif name in ('mailbox_hash_with_matching_receipts', 'mailbox_foreign_nonce_with_matching_receipt',
                          'mailbox_foreign_round_with_matching_receipt', 'native_api_failed_response_with_matching_receipt'):
                handoff = trial['handoffs'][0]
                if name == 'mailbox_hash_with_matching_receipts':
                    entries = list(handoff['mailbox'].values())
                    prefix, field, value = 'STATE_MAILBOX_JSON ', 'state_hash', '0000000000000000'
                elif name == 'mailbox_foreign_nonce_with_matching_receipt':
                    entries = [handoff['mailbox']['receive']]
                    prefix, field, value = 'STATE_MAILBOX_JSON ', 'nonce', '0000000000000001'
                elif name == 'mailbox_foreign_round_with_matching_receipt':
                    entries = [handoff['mailbox']['receive']]
                    prefix, field, value = 'STATE_MAILBOX_JSON ', 'round', 2
                else:
                    entries = [handoff['api_observations']['load']]
                    prefix, field, value = 'LAB_API_JSON ', 'response', 'HTTP/1.1 500 Internal Server Error\r\n\r\n'
                for entry in entries:
                    entry['receipt'][field] = value
                    path = directory / entry['file']
                    lines = path.read_text().splitlines()
                    assert sum(line.startswith(prefix) for line in lines) == 1
                    path.write_text('\n'.join(prefix + json.dumps(entry['receipt']) if line.startswith(prefix) else line
                                              for line in lines) + '\n')
            elif name == 'mailbox_duplicate_native_receipt':
                entry = trial['handoffs'][0]['mailbox']['receive']
                path = directory / entry['file']
                path.write_text(path.read_text().rstrip('\r\n') + '\nSTATE_MAILBOX_JSON ' + json.dumps(entry['receipt']) + '\n')
            elif name == 'native_helper_source_with_refreshed_sha':
                path = directory / 'measured-sources' / 'shared_probe.c'
                changed = path.read_bytes() + b'\n/* forged prepared helper source */\n'
                path.write_bytes(changed)
                report['runtime_sources']['shared_probe.c'] = sha(changed)
                full_audit = True
            elif name == 'reused_mailbox_trial_nonce':
                report['trials'][1]['mailbox_nonce'] = trial['mailbox_nonce']
                full_audit = True
            elif name in RAM_CASES:
                full_audit = mutate_ram_case(name, report, trial, directory)
            altered = directory / 'negative-report.json'
            dump(altered, report)
            try:
                if full_audit:
                    audit_args.report, audit_args.evidence_dir = altered, directory
                    with contextlib.redirect_stdout(io.StringIO()):
                        verifier.audit(audit_args)
                else:
                    verifier.audit_trial(trial, plan, trace, directory, memory_mib=original['arguments']['memory_mib'],
                                         state_transport=report['arguments'].get('state_transport', 'serial'),
                                         ram_lifecycle=report['arguments'].get('ram_lifecycle', 'shared-cxl'))
            except AssertionError as error:
                outcomes.append({'test': name, 'result': 'rejected', 'reason': str(error)})
            else:
                raise AssertionError(f'Corruption was accepted: {name}')
    result = {'schema_version': 1, 'result': 'passed', 'baseline_result': baseline['result'],
              'baseline_trials': baseline['trials'], 'baseline_commands': baseline['commands'],
              'verifier_sha256': sha(options.verifier.read_bytes()),
              'report_sha256': sha(options.report.read_bytes()),
              'script_sha256': sha(Path(__file__).read_bytes()), 'negative_cases': outcomes}
    dump(options.json_out, result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
