#!/usr/bin/env python3
"""Offline audit of safe direct-preflight rejection and diskless direct baseline.

All mutations are in-memory evidence forgeries. No VM is started or contacted.
API request descriptions come from the measured controller; full Firecracker
logs independently establish preflight/probe/Resume ordering where available.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Evidence:
    def __init__(self, directory, overrides=None):
        self.directory = Path(directory).resolve()
        self.overrides = overrides or {}

    def path(self, name):
        path = Path(name)
        return path if path.is_absolute() else self.directory/path

    def read(self, name):
        return self.overrides.get(str(name), self.path(name).read_bytes())

    def text(self, name):
        return self.read(name).decode().replace("\r", "")

    def rows(self, name, prefix):
        return [json.loads(line[len(prefix):]) for line in self.text(name).splitlines() if line.startswith(prefix)]


def baseline_audit(e, report):
    r = report
    require(r["compatibility"] == "supported_diskless_direct" and not r["api"], "baseline compatibility claim")
    path = Path("baseline/report.json") if e.path("baseline/report.json").is_file() else Path(r["baseline_report"])
    b = json.loads(e.read(path))
    require(b["result"] == "passed" and b["iterations"] == 20 and b["warmup"] == 0 and
            "Linux microVM cold-booted once" in b["guest"],
            "baseline run parameters")
    require(b["snapshot_bytes"] == b["ram_transfer_bytes"] == 0 and b["kernel_handoff_mode"] == 3 and
            b["control"] == "local" and b["reuse_fds"] is True, "baseline direct execution contract")
    validation = b["validation"]
    require(validation == r["baseline_validation"] and validation["handoffs"] == 20 and
            validation["boot_markers"] == 1 and validation["snapshot_api_calls"] == 0 and
            validation["vm_creates"] == validation["vcpu_creates"] == 1, "baseline nested validation mismatch")
    require(all(validation[key] == 0 for key in ("kernel_taint", "retained_heap_errors", "guest_clock_errors",
            "guest_tsc_errors", "host_backwards_tsc_warnings")) and
            validation["duplicate_attach_rejected"] is True and validation["old_owner_vcpu_access_revoked"] is True,
            "baseline continuity/ownership error")
    events = []
    for role in ("A", "B"):
        rows = e.rows(path.parent/f"{role}-probe.log", "LINUX_DIRECT_JSON ")
        require(rows == b["samples"][role], "baseline native/report mismatch")
        require(all(row["role"] == role for row in rows), "baseline native role mismatch")
        complete = [row for row in rows if row["event"] == "complete"]
        require(len(complete) == 1 and complete[0]["rounds"] == 20 and
                all(complete[0][key] == 0 for key in ("errors", "clock_errors", "tsc_errors")), "baseline native completion failure")
        require(rows[-1] == complete[0] and [row.get("round") for row in rows[:-1]] == list(range(20)),
                "baseline native per-role round chronology")
        require(all(row["event"] == ("source" if (number % 2 == 0) == (role == "A") else "destination")
                    for number, row in enumerate(rows[:-1])), "baseline native per-role event direction")
        events.extend(row for row in rows if row["event"] != "complete")
    require(len(events) == 40 and len({(row["vm_offset"], row["vcpu_offset"], row["vmcs_offset"]) for row in events}) == 1,
            "baseline object identity/event count")
    source_ept = set()
    last_sequence = -1
    for number in range(20):
        pair = [row for row in events if row["round"] == number]
        require(len(pair) == 2 and {row["event"] for row in pair} == {"source", "destination"}, "baseline handoff pair missing")
        source = next(row for row in pair if row["event"] == "source")
        target = next(row for row in pair if row["event"] == "destination")
        require(source["role"] == ("A" if number % 2 == 0 else "B") and source["role"] != target["role"] and
                target["sequence"] > source["sequence"] >= last_sequence, "baseline owner/heartbeat progression")
        require(source["vm_creates"] == source["vcpu_creates"] == 1, "baseline VM object recreated")
        require(all(math.isfinite(source[key]) and source[key] >= 0 for key in ("pause_us", "handoff_us", "guest_observed_us")),
                "baseline invalid latency")
        source_ept.add(source["ept_root_offset"])
        last_sequence = target["sequence"]
    require(source_ept == {validation["identical_ept_root_offset"]}, "baseline EPT root changed")
    summary = e.text(path.parent/"A-firecracker-summary.log")
    require(re.search(r"^FC_BOOT_COUNT=1$", summary, re.M) and re.search(r"^FC_SNAPSHOT_USED=0$", summary, re.M),
            "baseline one boot/zero snapshot evidence missing")
    return {"case": r["case"], "handoffs": 20, "native_events": 42,
            "snapshot_bytes": 0, "ram_transfer_bytes": 0, "continuity_errors": 0}


def audit(directory, report=None, overrides=None):
    e = Evidence(directory, overrides)
    r = copy.deepcopy(report) if report is not None else json.loads(e.read("report.json"))
    require(r["schema_version"] == 1 and r["result"] == "passed", "case did not pass")
    require(r["case"] in ("direct-block", "direct-two-vcpu", "direct-baseline"), "wrong test case")
    require(r["arguments"]["require_safe_direct_rejection"] is True and r["arguments"]["iterations"] == 20,
            "safe preflight contract not requested")
    require(not r["cleanup_errors"] and set(r["cleanup"]["owned_qemu_alive"]) == {"A", "B"} and
            not any(r["cleanup"]["owned_qemu_alive"].values()) and r["cleanup"]["cxl_backing_exists"] is False,
            "owned lab cleanup failure")
    require(set(r["runtime_sources"]) == {"mode_compatibility.py", "nfs_bench.py", "lab.py"}, "missing measured controller sources")
    for name, expected in r["runtime_sources"].items():
        require(sha(e.read("measured-sources/"+name)) == expected, "measured source SHA256 mismatch")
    require(r["config"]["dax_guest"] is True and r["config"]["dax_handoff"] is True, "wrong DAX mode")
    if r["case"] == "direct-baseline":
        return baseline_audit(e, r)
    block = r["case"] == "direct-block"
    require(r["compatibility"] == "rejected_by_existing_guard" and r["rejection_stage"] == "direct_preflight" and
            r["source_usable_after_rejection"] is True and r["ownership_unchanged"] is True,
            "unsafe rejection or unsupported compatibility claim")
    env = r["firecracker_environment"]
    require(env["FC_DAX_DIRECT"] == "1" and env["FC_DAX_RAM"] == "/dev/dax0.0" and
            env["FC_DAX_SNAPSHOT"] == "0" and env.get("FC_DAX_REUSE", "0") == "0", "wrong Firecracker direct mode")
    expected_paths = ["/machine-config", "/boot-source"] + (["/drives/data"] if block else []) + ["/actions", "/vm", "/", "/vm"]
    require([item["path"] for item in r["api"]] == expected_paths, "API sequence mismatch")
    for index, item in enumerate(r["api"]):
        rows = e.rows(f"api-{index:02d}.txt", "LAB_API_JSON ")
        require(len(rows) == 1 and all(item.get(key) == value for key, value in rows[0].items()), "API native/report mismatch")
        expected = 400 if index == len(expected_paths)-3 else (200 if index == len(expected_paths)-2 else 204)
        require(item["status"] == item["expected_status"] == expected and
                item["response"].startswith(f"HTTP/1.1 {expected} ") and
                type(item["duration_us"]) in (int, float) and math.isfinite(item["duration_us"]) and item["duration_us"] >= 0,
                "API response status/timing mismatch")
        require(re.search(r"^COMPAT_API_RC=0$", e.text(f"api-{index:02d}.txt"), re.M), "native API helper exit failure")
    configuration = r["guest_configuration"]
    require(configuration["/machine-config"] == {"vcpu_count": 1 if block else 2, "mem_size_mib": 512}, "guest CPU configuration")
    require(all(r["api"][i]["request"] == configuration[path] and r["api"][i]["method"] == "PUT"
                for i, path in enumerate(expected_paths[:-4])), "guest boot request mismatch")
    require(r["api"][-4]["request"] == {"action_type": "InstanceStart"} and r["api"][-4]["method"] == "PUT" and
            r["api"][-3]["request"] == {"state": "Paused"} and r["api"][-3]["method"] == "PATCH" and
            r["api"][-2]["method"] == "GET" and r["api"][-2]["request"] is None and
            r["api"][-1]["request"] == {"state": "Resumed"} and r["api"][-1]["method"] == "PATCH",
            "pause/resume request contract")
    require(r["source_api_after_rejection"] == r["api"][-2], "source API liveness metadata mismatch")
    status_body = json.loads(r["api"][-2]["response"].split("\r\n\r\n", 1)[1])
    require(status_body["state"] == "Running" and status_body["id"] == "anonymous-instance",
            "source API reports changed identity or non-running state after preflight")
    body = json.loads(r["api"][-3]["response"].split("\r\n\r\n", 1)[1])
    guard = "direct handoff supports diskless MMIO workers only" if block else "direct handoff requires one vCPU"
    require(body == {"fault_message": "Internal VMM error: Unsupported direct handoff configuration: " + guard},
            "wrong preflight rejection message")
    pools = []
    for boundary in ("before", "after"):
        pairs = re.findall(r"\b(state|owner|generation|vm_create_calls|vcpu_create_calls)=([0-9]+)", e.text(f"pool-{boundary}.txt"))
        require(len(pairs) == 5 and len({key for key, _ in pairs}) == 5, "pool observation ambiguous")
        pool = {key: int(value) for key, value in pairs}
        require(pool == r[f"pool_{boundary}"], "pool native/report mismatch")
        pools.append(pool)
    require(pools[0] == pools[1] and pools[0]["vm_create_calls"] == 1 and pools[0]["vcpu_create_calls"] == (1 if block else 2),
            "preflight changed owner/generation/object creation")
    log = e.read("source-firecracker.log")
    integrity = r["source_log_integrity"]
    require(len(log) == integrity["bytes"] and sha(log) == integrity["sha256"] and
            integrity["source_unchanged_during_fetch"] is True, "full source log integrity")
    lines = log.decode().replace("\r", "").splitlines()
    require(not re.search(r"Kernel panic|nfs-probe:|nfs_probe:|EXT4-fs error|Out of memory:|\bOops:", "\n".join(lines)), "source guest error")
    pause = [i for i, line in enumerate(lines) if 'Patch request on "/vm"' in line and 'Paused' in line]
    resume = [i for i, line in enumerate(lines) if 'Patch request on "/vm"' in line and 'Resumed' in line]
    rejected = [i for i, line in enumerate(lines) if 'Received Error. Status code: 400' in line and guard in line]
    require(len(pause) == len(resume) == len(rejected) == 1 and pause[0] < rejected[0] < resume[0], "full log preflight/Resume ordering")
    stages = ("source_before", "source_without_resume", "source_after")
    if block:
        drive = configuration["/drives/data"]
        require(drive["path_on_host"] == "/disk/sandbox.raw" and drive["is_read_only"] is True, "file-backed device configuration")
        probes = []
        for stage, label, offset in zip(stages, ("before_guard", "after_rejection_without_resume", "after_guard_cold"), (0, 64*1024**2, 128*1024**2)):
            item = r[stage]
            values = [json.loads(line) for line in e.text(label+".txt").splitlines() if line.startswith('{"event":"read"')]
            require(item["completed"] is True and len(values) == 1 and values[0] == item["read"], "native cold read missing or inconsistent")
            p = values[0]
            require(p["label"] == label and p["offset"] == offset and p["bytes"] == 1024**2 and p["block_bytes"] == 4096 and
                    p["mode"] == "seq" and p["seed"] == 1 and p["blocks"] == p["pread_calls"] == 256 and
                    p["ok"] is True and p["mismatched_words"] == 0 and p["first_bad_offset"] is None and
                    p["resident_before"] == 0 and p["resident_after"] == 256 and p["block_delta"]["read_sectors"] > 0,
                    "read did not validate uncached file data through virtio-blk")
            positions = [i for i, line in enumerate(lines) if line.startswith('{"event":"read"') and json.loads(line) == p]
            require(len(positions) == 1, "cold read absent/duplicated in full source log")
            probes.append((p, positions[0]))
        require(len({(p["pid"], p["open_cookie"]) for p, _ in probes}) == 1 and
                probes[0][1] < pause[0] < rejected[0] < probes[1][1] < resume[0] < probes[2][1],
                "guest identity or before-Resume cold read order lost")
        detail = {"validated_cold_reads": 3, "same_open_cookie": probes[0][0]["open_cookie"],
                  "read_before_resume": True, "read_after_resume": True}
    else:
        counters = [(i, int(m.group(1))) for i, line in enumerate(lines) if (m := re.fullmatch(r"L2_COUNTER=(\d+)\s*", line))]
        values = [r[stage]["counter"] for stage in stages]
        require(values[0] < values[1] < values[2], "guest counters did not progress across preflight and Resume")
        positions = []
        for value in values:
            found = [i for i, observed in counters if observed == value]
            require(len(found) == 1, "counter observation absent/duplicated in source log")
            positions.append(found[0])
        require(positions[0] < pause[0] < rejected[0] < positions[1] < resume[0] < positions[2],
                "two-vCPU guest progress was not observed before Resume")
        detail = {"configured_vcpus": 2, "guest_counter_before_without_resume_after": values}
    return {"case": r["case"], "raw_api_receipts": len(r["api"]), "preflight_rejected": True,
            "ownership_and_generation_unchanged": True, "source_usable_before_resume": True,
            "source_usable_after_resume": True, **detail}


def negatives(directory):
    e = Evidence(directory)
    original = json.loads(e.read("report.json"))
    names = ["failed_case", "cleanup", "source_hash", "compatibility", "contract_not_requested"]
    if original["case"] == "direct-baseline":
        names += ["baseline_handoff_count", "baseline_continuity_error", "baseline_sample_corruption", "baseline_native_reordered"]
    else:
        names += ["api_raw_disagreement", "guard_wrong_message", "pool_owner_changed", "source_log_tampered",
                  "wrong_guest_cpu_count", "preflight_stage", "source_unusable", "source_api_paused"]
        names += ["immediate_read_cached", "immediate_no_block_io", "fd_cookie_changed", "immediate_probe_timeout", "probe_after_resume"] if original["case"] == "direct-block" else ["counter_stalled", "counter_fabricated"]
    results = []
    for name in names:
        r, overrides = copy.deepcopy(original), {}
        if name == "failed_case": r["result"] = "failed"
        elif name == "cleanup": r["cleanup"]["cxl_backing_exists"] = True
        elif name == "source_hash": r["runtime_sources"]["mode_compatibility.py"] = "0"*64
        elif name == "compatibility": r["compatibility"] = "supported_block_direct"
        elif name == "contract_not_requested": r["arguments"]["require_safe_direct_rejection"] = False
        elif name == "baseline_handoff_count": r["baseline_validation"]["handoffs"] = 19
        elif name == "baseline_continuity_error": r["baseline_validation"]["retained_heap_errors"] = 1
        elif name == "baseline_sample_corruption":
            path = Path("baseline/report.json") if e.path("baseline/report.json").is_file() else Path(r["baseline_report"])
            b = json.loads(e.read(path)); b["samples"]["A"][0]["sequence"] += 1
            overrides[str(path)] = json.dumps(b).encode()
        elif name == "baseline_native_reordered":
            path = Path("baseline/report.json") if e.path("baseline/report.json").is_file() else Path(r["baseline_report"])
            b = json.loads(e.read(path)); b["samples"]["A"][0], b["samples"]["A"][1] = b["samples"]["A"][1], b["samples"]["A"][0]
            overrides[str(path)] = json.dumps(b).encode()
            raw_name = path.parent/"A-probe.log"
            lines = e.text(raw_name).splitlines()
            indices = [i for i,line in enumerate(lines) if line.startswith("LINUX_DIRECT_JSON ")]
            lines[indices[0]], lines[indices[1]] = lines[indices[1]], lines[indices[0]]
            overrides[str(raw_name)] = ("\n".join(lines)+"\n").encode()
        elif name == "api_raw_disagreement": r["api"][0]["status"] = 400
        elif name == "guard_wrong_message":
            idx = len(r["api"])-3; item = r["api"][idx]
            item["response"] = item["response"].replace("Unsupported direct handoff configuration", "Old unsafe pause export failed")
            native = {key: item[key] for key in ("status", "expected_status", "duration_us", "response")}
            overrides[f"api-{idx:02d}.txt"] = ("LAB_API_JSON "+json.dumps(native)+"\nCOMPAT_API_RC=0\n").encode()
        elif name == "pool_owner_changed":
            r["pool_after"]["owner"] += 1
            overrides["pool-after.txt"] = (" ".join(f"{key}={value}" for key, value in r["pool_after"].items())+"\n").encode()
        elif name == "source_log_tampered": overrides["source-firecracker.log"] = e.read("source-firecracker.log")+b"tampered\n"
        elif name == "wrong_guest_cpu_count": r["guest_configuration"]["/machine-config"]["vcpu_count"] = 3
        elif name == "preflight_stage": r["rejection_stage"] = "direct_pause_export"
        elif name == "source_unusable": r["source_usable_after_rejection"] = False
        elif name == "source_api_paused":
            idx = len(r["api"])-2; item = r["api"][idx]
            item["response"] = item["response"].replace('"Running"', '"Paused"')
            r["source_api_after_rejection"] = copy.deepcopy(item)
            native = {key: item[key] for key in ("status", "expected_status", "duration_us", "response")}
            overrides[f"api-{idx:02d}.txt"] = ("LAB_API_JSON "+json.dumps(native)+"\nCOMPAT_API_RC=0\n").encode()
        elif name in ("immediate_read_cached", "immediate_no_block_io", "fd_cookie_changed"):
            p = r["source_without_resume"]["read"]
            if name == "immediate_read_cached": p["resident_before"] = 256
            elif name == "immediate_no_block_io": p["block_delta"]["read_sectors"] = 0
            else: p["open_cookie"] = "0"*16
            overrides["after_rejection_without_resume.txt"] = (json.dumps(p,separators=(",", ":"))+"\n").encode()
            lines = e.text("source-firecracker.log").splitlines()
            index = next(i for i,line in enumerate(lines) if line.startswith('{"event":"read"') and '"label":"after_rejection_without_resume"' in line)
            lines[index] = json.dumps(p,separators=(",", ":"))
            data = ("\n".join(lines)+"\n").encode(); overrides["source-firecracker.log"] = data
            r["source_log_integrity"].update(bytes=len(data),sha256=sha(data))
        elif name == "immediate_probe_timeout":
            r["source_without_resume"] = {"completed": False}
            overrides["after_rejection_without_resume.txt"] = b"COMPAT_PROBE_TIMEOUT\n"
        elif name == "probe_after_resume":
            lines = e.text("source-firecracker.log").splitlines()
            index = next(i for i,line in enumerate(lines) if line.startswith('{"event":"read"') and '"label":"after_rejection_without_resume"' in line)
            line = lines.pop(index)
            index = next(i for i,line in enumerate(lines) if 'Patch request on "/vm"' in line and 'Resumed' in line)
            lines.insert(index+1,line)
            data = ("\n".join(lines)+"\n").encode(); overrides["source-firecracker.log"] = data
            r["source_log_integrity"].update(bytes=len(data),sha256=sha(data))
        elif name == "counter_stalled": r["source_without_resume"]["counter"] = r["source_before"]["counter"]
        elif name == "counter_fabricated": r["source_after"]["counter"] = 10**12
        try:
            audit(directory, r, overrides)
        except (ValueError, KeyError, AssertionError) as exc:
            results.append({"case": original["case"], "mutation": name, "rejected": True, "reason": str(exc)})
        else:
            raise AssertionError(f"forged evidence accepted: {name}")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", type=Path, nargs="+")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    cases = [audit(directory) for directory in args.directories]
    negative = [result for directory in args.directories for result in negatives(directory)]
    result = {"schema_version": 1, "result": "passed", "cases": cases, "negative_tests": negative,
              "reports": [{"directory":str(d), "sha256":sha((d/"report.json").read_bytes())} for d in args.directories],
              "verifier_sha256":sha(Path(__file__).read_bytes()),
              "limitations":["One coherent nested-KVM lab; unsupported block/two-vCPU direct migration remains rejected",
                              "API request metadata derives from measured controller; native responses and full logs checked independently",
                              "Cleanup is a recorded post-run assertion, not historical kernel-state reconstruction"]}
    args.out.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"result":"passed","cases":len(cases),"negative_rejections":len(negative),"output":str(args.out)}))


if __name__ == "__main__":
    main()
