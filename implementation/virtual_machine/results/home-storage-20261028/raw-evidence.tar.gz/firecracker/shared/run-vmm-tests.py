import subprocess, json, hashlib, time
from pathlib import Path
root='/tmp/firecracker-home-storage-20261028'
base=['docker','run','--rm','--pull','never','--network','none','--cpuset-cpus','6-11,30-35','--user','1001:1001','--group-add','108','--device','/dev/kvm','--security-opt','seccomp=unconfined','--volume',root+':/firecracker','--volume',root+'/build/cargo_registry:/usr/local/rust/registry','--volume',root+'/build/cargo_git_registry:/usr/local/rust/git','--workdir','/firecracker','public.ecr.aws/firecracker/fcuvm:v93']
results=[]
for label,pattern in [('prepare','test_prepare_save'),('snapshot','test_storage_snapshot_flush_failure'),('direct','test_direct_handoff_preflight'),('reuse','reuse::tests')]:
 cmd=base+['cargo','test','-p','vmm',pattern,'--offline','--locked','--release','--target','x86_64-unknown-linux-musl','--','--test-threads=1']
 log=Path('/tmp/fc-storage-safety-'+label+'-tests.log')
 start=time.monotonic()
 with log.open('w') as stream: r=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
 results.append({'label':label,'command':cmd,'exit_code':r.returncode,'elapsed_s':time.monotonic()-start,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 print(label, r.returncode,flush=True)
 Path('/tmp/fc-storage-safety-tests.json').write_text(json.dumps(results,indent=2)+'\n')
 if r.returncode: raise SystemExit(r.returncode)
