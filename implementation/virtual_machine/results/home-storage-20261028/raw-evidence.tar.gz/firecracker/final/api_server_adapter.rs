// Copyright 2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

use std::os::unix::io::AsRawFd;
use std::io::{Read, Write};
use std::os::unix::net::{UnixListener, UnixStream};
use std::path::PathBuf;
use std::sync::mpsc::{Receiver, Sender, TryRecvError, channel};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use event_manager::{EventOps, Events, MutEventSubscriber, SubscriberOps};
use vmm::logger::{ProcessTimeReporter, error_unrestricted, info_unrestricted, warn_unrestricted};
use vmm::rpc_interface::{
    ApiRequest, ApiResponse, BuildMicrovmFromRequestsError, PrebootApiController,
    RuntimeApiController, VmmAction,
};
use vmm::seccomp::BpfThreadMap;
use vmm::vmm_config::instance_info::InstanceInfo;
use vmm::{EventManager, FcExitCode, Vmm};
use vmm_sys_util::epoll::EventSet;
use vmm_sys_util::eventfd::EventFd;

use super::api_server::{ApiServer, HttpServer, ServerError};

#[derive(Debug, thiserror::Error, displaydoc::Display)]
pub enum ApiServerError {
    /// Failed to build MicroVM: {0}.
    BuildMicroVmError(BuildMicrovmFromRequestsError),
    /// MicroVM stopped with an error: {0:?}
    MicroVMStoppedWithError(FcExitCode),
    /// Failed to open the API socket at: {0}. Check that it is not already used.
    FailedToBindSocket(String),
    /// Failed to bind and run the HTTP server: {0}
    FailedToBindAndRunHttpServer(ServerError),
    /// Failed to build MicroVM from Json: {0}
    BuildFromJson(crate::BuildFromJsonError),
    /// Missing vmm seccomp filter
    MissingSeccompFilter,
    /// Failed to install vmm seccomp filter: {0}
    SeccompFilter(vmm::seccomp::InstallationError),
}

#[derive(Debug)]
struct ApiServerAdapter {
    api_event_fd: EventFd,
    from_api: Receiver<ApiRequest>,
    to_api: Sender<ApiResponse>,
    controller: RuntimeApiController,
    request: Option<ApiRequest>,
}

/// Opt-in laboratory control: one persistent local connection, no HTTP/API thread.
/// The pause loop also freezes device event dispatch, like the normal API adapter.
struct DaxControl {
    listener: UnixListener,
    stream: Option<UnixStream>,
    vmm: Arc<Mutex<Vmm>>,
}

impl DaxControl {
    fn new(vmm: Arc<Mutex<Vmm>>) -> Option<Self> {
        let path = std::env::var("FC_DAX_CONTROL").ok()?;
        assert_eq!(std::env::var("FC_DAX_DIRECT").as_deref(), Ok("1"));
        let listener = UnixListener::bind(path).expect("DAX control bind");
        listener.set_nonblocking(true).expect("DAX control nonblocking");
        Some(Self { listener, stream: None, vmm })
    }
}

impl MutEventSubscriber for DaxControl {
    fn init(&mut self, ops: &mut EventOps) {
        ops.add(Events::new(&self.listener, EventSet::IN)).expect("DAX control epoll");
    }

    fn process(&mut self, event: Events, ops: &mut EventOps) {
        if event.fd() == self.listener.as_raw_fd() {
            let (stream, _) = self.listener.accept().expect("DAX control accept");
            assert!(self.stream.is_none(), "Only one DAX controller is supported");
            stream.set_write_timeout(Some(Duration::from_secs(60))).unwrap();
            ops.add(Events::new(&stream, EventSet::IN)).expect("DAX stream epoll");
            self.stream = Some(stream);
            return;
        }
        let stream = self.stream.as_mut().expect("DAX control stream");
        let mut paused = false;
        // A stopped microVM must not dispatch its device callbacks while B owns it.
        loop {
            let mut command = [0u8; 1];
            if let Err(error) = stream.read_exact(&mut command) {
                if error.kind() == std::io::ErrorKind::UnexpectedEof {
                    assert!(!paused, "DAX controller disconnected while detached");
                    ops.remove(Events::new(stream, EventSet::IN)).unwrap();
                    self.stream = None;
                    return;
                }
                panic!("DAX control read: {error}");
            }
            let start = Instant::now();
            let result = match command[0] {
                1 => self.vmm.lock().unwrap().pause_vm(),
                2 => self.vmm.lock().unwrap().resume_vm(),
                _ => panic!("Invalid DAX control command"),
            };
            // Fixed native-endian record, local same-host socket only.
            let status = if result.is_ok() { 0u64 } else { libc::EIO as u64 };
            paused = command[0] == 1;
            let mut response = [0u8; 40];
            response[..8].copy_from_slice(&status.to_ne_bytes());
            response[8..16].copy_from_slice(&(start.elapsed().as_nanos() as u64).to_ne_bytes());
            for (i, value) in vmm::DAX_CONTROL_TIMINGS.iter().enumerate() {
                response[16+i*8..24+i*8].copy_from_slice(&value.load(std::sync::atomic::Ordering::Relaxed).to_ne_bytes());
            }
            stream.write_all(&response).expect("DAX control response");
            result.expect("DAX handoff failed");
            if command[0] == 2 {
                return;
            }
        }
    }
}

impl ApiServerAdapter {
    /// Runs the vmm to completion, while any arising control events are deferred
    /// to a `RuntimeApiController`.
    fn run_microvm(
        api_event_fd: EventFd,
        from_api: Receiver<ApiRequest>,
        to_api: Sender<ApiResponse>,
        vmm: Arc<Mutex<Vmm>>,
        event_manager: &mut EventManager,
    ) -> Result<(), ApiServerError> {
        if let Some(control) = DaxControl::new(vmm.clone()) {
            event_manager.add_subscriber(Arc::new(Mutex::new(control)));
        }
        let api_adapter = Arc::new(Mutex::new(Self {
            api_event_fd,
            from_api,
            to_api,
            controller: RuntimeApiController::new(vmm.clone()),
            request: None,
        }));
        event_manager.add_subscriber(api_adapter.clone());
        loop {
            event_manager
                .run()
                .expect("EventManager events driver fatal error");
            api_adapter
                .lock()
                .expect("Poisoned lock")
                .handle_request(event_manager);

            match vmm.lock().unwrap().shutdown_exit_code() {
                Some(FcExitCode::Ok) => break,
                Some(exit_code) => return Err(ApiServerError::MicroVMStoppedWithError(exit_code)),
                None => continue,
            }
        }
        Ok(())
    }

    fn _handle_request(&mut self, req_action: VmmAction, event_manager: &mut EventManager) -> bool {
        let response = self.controller.handle_request(req_action, event_manager);
        let succeeded = response.is_ok();
        // Send back the result.
        self.to_api
            .send(Box::new(response))
            .map_err(|_| ())
            .expect("one-shot channel closed");
        succeeded
    }

    fn handle_request(&mut self, event_manager: &mut EventManager) {
        if let Some(api_request) = self.request.take() {
            let request_is_pause = *api_request == VmmAction::Pause;
            let request_succeeded = self._handle_request(*api_request, event_manager);

            // After an accepted pause request, temporarily switch to a mode where we
            // do blocking `recv`s on the `from_api` receiver in a loop, until we get
            // unpaused. The device emulation is implicitly paused since we do not
            // relinquish control to the event manager because we're not returning from
            // `handle_request`.
            // A rejected pause must leave UART and block event dispatch running.
            if request_is_pause && request_succeeded {
                // This loop only attempts to process API requests, so things like the
                // metric flush timerfd handling are frozen as well.
                loop {
                    let req = self.from_api.recv().expect("Error receiving API request.");
                    let req_is_resume = *req == VmmAction::Resume;
                    let request_succeeded = self._handle_request(*req, event_manager);
                    if req_is_resume && request_succeeded {
                        break;
                    }
                }
            }
        }
    }
}
impl MutEventSubscriber for ApiServerAdapter {
    /// Handle a read event (EPOLLIN).
    fn process(&mut self, event: Events, _: &mut EventOps) {
        let source = event.fd();
        let event_set = event.event_set();

        if source == self.api_event_fd.as_raw_fd() && event_set == EventSet::IN {
            let _ = self.api_event_fd.read();
            match self.from_api.try_recv() {
                Ok(api_request) => {
                    self.request = Some(api_request);
                }
                Err(TryRecvError::Empty) => {
                    warn_unrestricted!("Got a spurious notification from api thread");
                }
                Err(TryRecvError::Disconnected) => {
                    panic!("The channel's sending half was disconnected. Cannot receive data.");
                }
            };
        } else {
            error_unrestricted!("Spurious EventManager event for handler: ApiServerAdapter");
        }
    }

    fn init(&mut self, ops: &mut EventOps) {
        if let Err(err) = ops.add(Events::new(&self.api_event_fd, EventSet::IN)) {
            error_unrestricted!("Failed to register activate event: {}", err);
        }
    }
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn run_with_api(
    seccomp_filters: &mut BpfThreadMap,
    config_json: Option<String>,
    bind_path: PathBuf,
    instance_info: InstanceInfo,
    process_time_reporter: ProcessTimeReporter,
    boot_timer_enabled: bool,
    pci_enabled: bool,
    api_payload_limit: usize,
    mmds_size_limit: usize,
    metadata_json: Option<&str>,
) -> Result<(), ApiServerError> {
    // FD to notify of API events. This is a blocking eventfd by design.
    // It is used in the config/pre-boot loop which is a simple blocking loop
    // which only consumes API events.
    let api_event_fd = EventFd::new(libc::EFD_SEMAPHORE).expect("Cannot create API Eventfd.");
    // FD used to signal API thread to stop/shutdown.
    let api_kill_switch = EventFd::new(libc::EFD_NONBLOCK).expect("Cannot create API kill switch.");

    // Channels for both directions between Vmm and Api threads.
    let (to_vmm, from_api) = channel();
    let (to_api, from_vmm) = channel();

    let to_vmm_event_fd = api_event_fd
        .try_clone()
        .expect("Failed to clone API event FD");
    let api_seccomp_filter = seccomp_filters
        .remove("api")
        .expect("Missing seccomp filter for API thread.");

    let mut server = match HttpServer::new(&bind_path) {
        Ok(s) => s,
        Err(ServerError::IOError(inner)) if inner.kind() == std::io::ErrorKind::AddrInUse => {
            let sock_path = bind_path.display().to_string();
            return Err(ApiServerError::FailedToBindSocket(sock_path));
        }
        Err(err) => {
            return Err(ApiServerError::FailedToBindAndRunHttpServer(err));
        }
    };
    info_unrestricted!("Listening on API socket ({bind_path:?}).");

    let api_kill_switch_clone = api_kill_switch
        .try_clone()
        .expect("Failed to clone API kill switch");

    server
        .add_kill_switch(api_kill_switch_clone)
        .expect("Cannot add HTTP server kill switch");

    // Start the separate API thread.
    let api_thread = thread::Builder::new()
        .name("fc_api".to_owned())
        .spawn(move || {
            ApiServer::new(to_vmm, from_vmm, to_vmm_event_fd).run(
                server,
                process_time_reporter,
                &api_seccomp_filter,
                api_payload_limit,
            );
        })
        .expect("API thread spawn failed.");

    let mut event_manager = EventManager::new().expect("Unable to create EventManager");

    // Create the firecracker metrics object responsible for periodically printing metrics.
    let firecracker_metrics = Arc::new(Mutex::new(super::metrics::PeriodicMetrics::new()));
    event_manager.add_subscriber(firecracker_metrics.clone());

    // Configure, build and start the microVM.
    let build_result = match config_json {
        Some(json) => super::build_microvm_from_json(
            seccomp_filters,
            &mut event_manager,
            json,
            instance_info,
            boot_timer_enabled,
            pci_enabled,
            mmds_size_limit,
            metadata_json,
        )
        .map_err(ApiServerError::BuildFromJson),
        None => PrebootApiController::build_microvm_from_requests(
            seccomp_filters,
            &mut event_manager,
            instance_info,
            &from_api,
            &to_api,
            &api_event_fd,
            boot_timer_enabled,
            pci_enabled,
            mmds_size_limit,
            metadata_json,
        )
        .map_err(ApiServerError::BuildMicroVmError),
    };

    // INVARIANT: seccomp must be applied before entering the event loop.
    // No guest-facing operations may occur between builder return and filter installation.
    let result = build_result.and_then(|vmm| {
        vmm::seccomp::apply_filter(
            seccomp_filters
                .get("vmm")
                .ok_or(ApiServerError::MissingSeccompFilter)?,
        )
        .map_err(ApiServerError::SeccompFilter)?;

        firecracker_metrics
            .lock()
            .expect("Poisoned lock")
            .start(super::metrics::WRITE_METRICS_PERIOD_MS);

        ApiServerAdapter::run_microvm(api_event_fd, from_api, to_api, vmm, &mut event_manager)
    });

    api_kill_switch.write(1).unwrap();
    // This call to thread::join() should block until the API thread has processed the
    // shutdown-internal and returns from its function.
    api_thread.join().expect("Api thread should join");

    result
}

#[cfg(all(test, target_arch = "x86_64"))]
mod tests {
    use std::sync::atomic::{AtomicUsize, Ordering};

    use super::*;

    struct DeviceEventProbe {
        event: EventFd,
        dispatched: Arc<AtomicUsize>,
    }

    impl MutEventSubscriber for DeviceEventProbe {
        fn init(&mut self, ops: &mut EventOps) {
            ops.add(Events::new(&self.event, EventSet::IN)).unwrap();
        }

        fn process(&mut self, _: Events, _: &mut EventOps) {
            self.event.read().unwrap();
            self.dispatched.fetch_add(1, Ordering::SeqCst);
        }
    }

    fn device_probe(event_manager: &mut EventManager) -> (EventFd, Arc<AtomicUsize>) {
        let event = EventFd::new(libc::EFD_NONBLOCK).unwrap();
        let dispatched = Arc::new(AtomicUsize::new(0));
        event_manager.add_subscriber(Arc::new(Mutex::new(DeviceEventProbe {
            event: event.try_clone().unwrap(),
            dispatched: dispatched.clone(),
        })));
        (event, dispatched)
    }

    #[test]
    fn test_rejected_pause_returns_to_device_event_dispatch() {
        // Set the opt-in environment in a child process, without racing other tests
        // or mutating the environment after the vCPU threads have started.
        const CHILD: &str = "FC_TEST_REJECTED_PAUSE_CHILD";
        if std::env::var(CHILD).as_deref() != Ok("1") {
            assert!(std::process::Command::new(std::env::current_exe().unwrap())
                .args(["--exact", "api_server_adapter::tests::test_rejected_pause_returns_to_device_event_dispatch", "--test-threads=1"])
                .env(CHILD, "1")
                .env("FC_DAX_DIRECT", "1")
                .status().unwrap().success());
            return;
        }
        let (vmm, mut event_manager) = vmm::test_utils::default_vmm_no_boot(None);
        vmm.lock().unwrap().machine_config.vcpu_count = 2;
        let state_before = vmm.lock().unwrap().instance_info.state.clone();
        let (to_vmm, from_api) = channel();
        let (to_api, from_vmm) = channel();
        let api_event = EventFd::new(libc::EFD_NONBLOCK).unwrap();
        let adapter = Arc::new(Mutex::new(ApiServerAdapter {
            api_event_fd: api_event.try_clone().unwrap(),
            from_api, to_api,
            controller: RuntimeApiController::new(vmm.clone()),
            request: None,
        }));
        event_manager.add_subscriber(adapter.clone());
        let (device_event, dispatched) = device_probe(&mut event_manager);
        to_vmm.send(Box::new(VmmAction::Pause)).unwrap();
        // Old behavior tries another blocking receive after rejection and panics
        // on this disconnected channel, instead of hanging the regression test.
        drop(to_vmm);
        api_event.write(1).unwrap();
        event_manager.run_with_timeout(100).unwrap();
        adapter.lock().unwrap().handle_request(&mut event_manager);
        let error = (*from_vmm.recv_timeout(Duration::from_secs(1)).unwrap()).unwrap_err();
        assert!(error.to_string().contains("direct handoff requires one vCPU"));
        assert_eq!(vmm.lock().unwrap().instance_info.state, state_before);
        device_event.write(1).unwrap();
        event_manager.run_with_timeout(100).unwrap();
        assert_eq!(dispatched.load(Ordering::SeqCst), 1);
    }

}
