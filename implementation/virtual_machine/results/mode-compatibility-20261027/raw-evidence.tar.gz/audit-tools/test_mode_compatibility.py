#!/usr/bin/env python3
"""Non-VM parser fault tests for the exact compatibility runner source."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import shlex
import tempfile
import types


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    raw = args.source.read_bytes()
    tree = ast.parse(raw)
    top = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "main")
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "require"]
    functions += [node for node in top.body if isinstance(node, ast.FunctionDef) and node.name in ("api", "bounded_probe")]
    module = ast.Module(body=functions, type_ignores=[])
    outcomes = []
    with tempfile.TemporaryDirectory(prefix="compat-unit-") as directory:
        env = {"json": json, "shlex": shlex, "out": Path(directory), "directory": "/run/compat-unit",
               "report": {"api": []}, "save": lambda: None}
        exec(compile(module, str(args.source), "exec"), env)

        def run(name, text, reject=False, action=None):
            env["nfs"] = types.SimpleNamespace(shell=lambda *a, **kw: text)
            caught = None
            value = None
            try:
                value = (action or (lambda: env["bounded_probe"]({}, "unit", 0)))()
            except (RuntimeError, KeyError, json.JSONDecodeError) as exc:
                caught = type(exc).__name__
            passed = bool(caught) if reject else caught is None
            if name == "echoed_timeout_literal_accepted":
                passed = passed and value["completed"]
            if name == "anchored_timeout_observed":
                passed = passed and not value["completed"]
            outcomes.append({"name": name, "passed": passed, "exception": caught})

        valid = {"event": "read", "label": "unit", "ok": True, "mismatched_words": 0}
        row = json.dumps(valid, separators=(",", ":")) + "\n"
        run("echoed_timeout_literal_accepted", "> if false; then echo COMPAT_PROBE_TIMEOUT; fi\n" + row)
        run("anchored_timeout_observed", "COMPAT_PROBE_TIMEOUT\n")
        run("missing_result_rejected", "> grep pattern /run/log\n", True)
        run("truncated_result_rejected", '{"event":"read",\n', True)
        run("duplicate_result_rejected", row + row, True)
        run("wrong_label_rejected", row.replace('"unit"', '"wrong"'), True)
        run("corrupt_data_rejected", row.replace('"mismatched_words":0', '"mismatched_words":1'), True)
        run("guest_failure_rejected", row.replace('"ok":true', '"ok":false'), True)
        api_row = {"status": 204, "expected_status": 204, "duration_us": 1, "response": "HTTP/1.1 204"}
        line = "LAB_API_JSON " + json.dumps(api_row) + "\n"
        action = lambda: env["api"]({}, "PATCH", "/vm", {"state": "Paused"})
        run("api_response_accepted_and_raw_saved", line, action=action)
        assert (Path(directory) / "api-00.txt").read_text() == line
        run("api_wrong_status_rejected", line.replace('"status": 204', '"status": 400'), True, action)
        run("api_duplicate_response_rejected", line + line, True, action)
        run("api_echo_only_rejected", "> printf 'LAB_API_JSON fake'\n", True, action)
    result = {"source": str(args.source), "source_sha256": hashlib.sha256(raw).hexdigest(),
              "tests": outcomes, "passed": sum(row["passed"] for row in outcomes), "total": len(outcomes)}
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    assert result["passed"] == result["total"]


if __name__ == "__main__":
    main()
