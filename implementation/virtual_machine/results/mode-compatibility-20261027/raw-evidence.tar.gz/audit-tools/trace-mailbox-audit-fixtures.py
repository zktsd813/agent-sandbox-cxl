#!/usr/bin/env python3
"""Exercise mailbox evidence rejection offline with a known FNV-1a64 vector."""
import argparse
import copy
import importlib.util
import json
from pathlib import Path
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument("--verifier", type=Path, required=True)
p.add_argument("--json-out", type=Path, required=True)
args = p.parse_args()
spec = importlib.util.spec_from_file_location("verifier", args.verifier)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
rejected = []
with tempfile.TemporaryDirectory(prefix="mailbox-audit-fixture-") as td:
    d = Path(td)
    payload = b"hello"
    (d / "src").write_bytes(payload)
    (d / "dst").write_bytes(payload)
    trial = {"id": "fixture", "mailbox_nonce": "1234567890abcdef"}
    handoff = {"source": "A", "destination": "B", "state_transport": "dax-mailbox", "handoff_mode": "snapshot", "state_file": "src",
               "destination_state_file": "dst", "destination_prestarted": True,
               "destination_state_integrity": {"bytes": 5, "sha256": v.sha(payload), "source_unchanged_during_fetch": True},
               "mailbox": {}, "api_observations": {}}
    for phase in ("publish", "receive"):
        receipt = {"phase": phase, "role": "A" if phase == "publish" else "B", "source_role": "A",
                   "nonce": trial["mailbox_nonce"], "round": 1, "schema": "534e415053484f02", "offset": 1048576,
                   "capacity": 262144, "memory_bytes": 2147483648, "state_bytes": 5,
                   "state_hash": "a430d84680aabd0b", "duration_ns": 1}
        handoff["mailbox"][phase] = {"file": phase, "receipt": receipt}
    for phase in ("pause", "snapshot", "load", "resume"):
        handoff["api_observations"][phase] = {"file": phase, "receipt": {"status": 204, "expected_status": 204,
            "duration_us": 1.2, "response": "HTTP/1.1 204 No Content\r\nContent-Length: 0\r\n\r\n"}}

    def write_records(record):
        for section, prefix in (("mailbox", "STATE_MAILBOX_JSON "), ("api_observations", "LAB_API_JSON ")):
            for evidence in record[section].values():
                (d / evidence["file"]).write_text(prefix + json.dumps(evidence["receipt"]) + "\n")

    def check(record):
        return v.audit_state_transport(record, trial, 0, d, 2147483648, "dax-mailbox")

    def reject(record, name):
        try:
            check(record)
        except AssertionError as error:
            rejected.append({"case": name, "error": str(error)})
        else:
            raise AssertionError("Accepted corrupted evidence: " + name)

    write_records(handoff)
    check(handoff)
    for field, value in (("nonce", "0000000000000001"), ("round", 2), ("schema", "534e415053484f03"),
                         ("offset", 2097152), ("capacity", 524288), ("memory_bytes", 1073741824),
                         ("state_hash", "0000000000000000"), ("role", "A"), ("duration_ns", -1)):
        modified = copy.deepcopy(handoff)
        modified["mailbox"]["receive"]["receipt"][field] = value
        write_records(modified)
        reject(modified, field)
    write_records(handoff)
    (d / "dst").write_bytes(b"jello")
    reject(handoff, "destination bytes")
    (d / "dst").write_bytes(payload)
    (d / "receive").write_text((d / "receive").read_text() * 2)
    reject(handoff, "duplicate receipt")
    modified = copy.deepcopy(handoff)
    modified["api_observations"]["load"]["receipt"]["response"] = "HTTP/1.1 500 Internal Server Error\r\n\r\n"
    write_records(modified)
    reject(modified, "API response disagrees with status")
    modified = copy.deepcopy(handoff)
    modified["handoff_mode"] = "direct"
    write_records(modified)
    reject(modified, "handoff mislabeled as direct")
result = {"result": "passed", "baseline": "passed", "verifier_sha256": v.digest(args.verifier),
          "negative_cases_rejected": len(rejected), "cases": rejected}
args.json_out.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
