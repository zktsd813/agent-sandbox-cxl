#!/usr/bin/env python3
"""Cross-check compatibility reports against raw evidence without running VMs."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re


def check(ok, message):
    if not ok:
        raise ValueError(message)


def rows(path, prefix):
    return [json.loads(line[len(prefix):]) for line in path.read_text().splitlines() if line.startswith(prefix)]


def audit(directory, report=None):
    r = report if report is not None else json.loads((directory / "report.json").read_text())
    check(r["result"] == "passed", "Case did not complete its assertions")
    check(not r["cleanup_errors"], "Cleanup error")
    check(not any(r["cleanup"]["owned_qemu_alive"].values()) and not r["cleanup"]["cxl_backing_exists"], "Cleanup state")
    for name, expected in r["runtime_sources"].items():
        check(hashlib.sha256((directory / "measured-sources" / name).read_bytes()).hexdigest() == expected, "Source hash")
    for index, receipt in enumerate(r["api"]):
        raw = rows(directory / f"api-{index:02d}.txt", "LAB_API_JSON ")
        check(len(raw) == 1, "Ambiguous API receipt")
        check(all(receipt[key] == value for key, value in raw[0].items()), "API report differs from raw")
        check(receipt["status"] == receipt["expected_status"], "Unexpected API status")
    if r["case"] == "direct-baseline":
        packaged = directory / "baseline" / "report.json"
        p = packaged if packaged.is_file() else Path(r["baseline_report"])
        baseline = json.loads(p.read_text())
        check(baseline["validation"] == r["baseline_validation"], "Baseline nested validation differs")
        check(baseline["result"] == "passed" and baseline["iterations"] == 20 and baseline["warmup"] == 0, "Wrong baseline")
        check(r["compatibility"] == "supported_diskless_direct", "Baseline mode claim")
        samples = []
        for role in ("A", "B"):
            raw = rows(p.parent / f"{role}-probe.log", "LINUX_DIRECT_JSON ")
            check(raw == baseline["samples"][role], "Direct samples differ from raw")
            complete = [row for row in raw if row["event"] == "complete"]
            check(len(complete) == 1 and complete[0]["rounds"] == 20, "Direct completion")
            check(all(complete[0][key] == 0 for key in ("errors", "clock_errors", "tsc_errors")), "Direct continuity error")
            samples.extend(row for row in raw if row["event"] != "complete")
        check(len(samples) == 40, "Direct event count")
        identity = {(x["vm_offset"], x["vcpu_offset"], x["vmcs_offset"]) for x in samples}
        check(len(identity) == 1, "Changed direct object")
        for i in range(20):
            pair = [row for row in samples if row["round"] == i]
            check(len(pair) == 2 and {row["event"] for row in pair} == {"source", "destination"}, "Missing handoff pair")
            source = next(row for row in pair if row["event"] == "source")
            target = next(row for row in pair if row["event"] == "destination")
            check(target["sequence"] > source["sequence"] and source["role"] != target["role"], "Missing new-owner progress")
            check(source["vm_creates"] == source["vcpu_creates"] == 1, "Recreated direct object")
        check(len({row["ept_root_offset"] for row in samples if row["event"] == "source"}) == 1, "Changed EPT root")
        summary = (p.parent / "A-firecracker-summary.log").read_text()
        check(re.search(r"^FC_BOOT_COUNT=1$", summary, re.M) and re.search(r"^FC_SNAPSHOT_USED=0$", summary, re.M), "Not one boot / zero snapshots")
        return {"case": r["case"], "directory": str(directory), "handoffs": 20, "raw_api_receipts": 0}
    direct = r["case"].startswith("direct")
    block = r["case"].endswith("block")
    check(r["compatibility"] == "rejected_by_existing_guard", "Negative case misrepresented as compatibility")
    rejected = [row for row in r["api"] if row["status"] == 400]
    check(len(rejected) == 1, "Wrong rejection count")
    if direct:
        check(rejected[0]["path"] == "/vm" and "os error 95" in rejected[0]["response"], "Wrong direct guard")
        for boundary in ("before", "after"):
            text = (directory / f"pool-{boundary}.txt").read_text()
            derived = {key: int(value) for key, value in re.findall(r"\b(state|owner|generation|vm_create_calls|vcpu_create_calls)=([0-9]+)", text)}
            check(derived == r[f"pool_{boundary}"], "Pool report differs from raw")
        check(all(r["pool_before"][key] == r["pool_after"][key] for key in ("state", "owner", "generation")), "Ownership changed")
        check(r["ownership_unchanged"], "Ownership claim")
    else:
        text = "diskless MMIO workers only" if block else "one-vCPU"
        check(rejected[0]["path"] == "/actions" and text in rejected[0]["response"], "Wrong reuse guard")
    if block:
        for boundary, label in (("before", "before_guard"), ("after", "after_guard_cold")):
            output = (directory / (label + ".txt")).read_text()
            observed = r[f"source_{boundary}"]
            probe = [json.loads(line) for line in output.splitlines() if line.startswith('{"event":"read"')]
            if observed["completed"]:
                check(len(probe) == 1 and probe[0] == observed["read"], "Read report differs from raw")
                check(probe[0]["ok"] and probe[0]["mismatched_words"] == 0 and probe[0]["resident_before"] == 0, "Invalid cold read")
                check(probe[0]["block_delta"]["read_sectors"] > 0, "Cold backing I/O missing")
            else:
                check(not probe and any(line.strip() == "COMPAT_PROBE_TIMEOUT" for line in output.splitlines()), "Timeout not supported by raw output")
        usable = r["source_after"]["completed"]
        if usable:
            check(r["source_before"]["read"]["open_cookie"] == r["source_after"]["read"]["open_cookie"], "Guest FD identity changed")
    else:
        counters = [int(value) for value in re.findall(r"^L2_COUNTER=(\d+)\s*$", (directory / "source-firecracker.log").read_text(), re.M)]
        before, after = r["source_before"]["counter"], r["source_after"]["counter"]
        check(before in counters and after in counters, "Counter missing from actual source log")
        usable = after > before
    check(r["source_usable_after_rejection"] == usable, "Source recovery claim")
    check(usable == (r["case"] != "direct-block"), "Unexpected source recovery behavior")
    return {"case": r["case"], "directory": str(directory), "raw_api_receipts": len(r["api"]), "source_usable": usable}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directories", type=Path, nargs="+")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    audited = [audit(path) for path in args.directories]
    negative = []
    for directory in args.directories:
        original = json.loads((directory / "report.json").read_text())
        mutations = ["cleanup", "source_hash", "compatibility"]
        mutations += ["baseline_handoffs"] if original["case"] == "direct-baseline" else ["api_status", "source_recovery"]
        if original["case"].startswith("direct") and original["case"] != "direct-baseline":
            mutations.append("pool_owner")
        if original["case"].endswith("block"):
            mutations.append("read_latency")
        for mutation in mutations:
            changed = copy.deepcopy(original)
            if mutation == "cleanup": changed["cleanup"]["cxl_backing_exists"] = True
            elif mutation == "source_hash": changed["runtime_sources"]["mode_compatibility.py"] = "0" * 64
            elif mutation == "compatibility": changed["compatibility"] = "fabricated_compatibility"
            elif mutation == "baseline_handoffs": changed["baseline_validation"]["handoffs"] += 1
            elif mutation == "api_status": changed["api"][0]["status"] = 999
            elif mutation == "source_recovery": changed["source_usable_after_rejection"] = not changed["source_usable_after_rejection"]
            elif mutation == "pool_owner": changed["pool_after"]["owner"] += 1
            elif mutation == "read_latency": changed["source_before"]["read"]["wall_ns"] *= 1000
            try:
                audit(directory, changed)
            except (ValueError, KeyError) as exc:
                negative.append({"case": original["case"], "mutation": mutation, "rejected": True, "error": str(exc)})
            else:
                raise AssertionError(f"Accepted mutation {mutation}: {directory}")
    result = {"schema_version": 1, "result": "passed", "audited": audited, "negative_tests": negative,
              "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "scope": "Raw API/probe/pool/counter and direct-controller event evidence; cleanup checks recorded reports, not historical kernel state"}
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"result": "passed", "cases": len(audited), "negative_tests": len(negative), "out": str(args.out)}))


if __name__ == "__main__":
    main()
