#!/usr/bin/env python3
"""Audit native state-only controller logs and their archival hashes; no VMs."""
import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def audit(path, mode, supplied=None):
    report = supplied if supplied is not None else json.loads(path.read_text())
    out = path.parent
    require(report["result"] == "passed", "Incomplete benchmark")
    require(report["iterations"] == 20 and report["warmup"] == 4 and report["memory_mib"] == 128, "Unexpected matrix")
    reuse, prepared = mode != "snapshot", mode == "reuse-prepared"
    require(report["reuse_kvm"] == reuse and report["reuse_prepare"] == prepared, "Mode mismatch")
    require(report["ram_transfer_bytes"] == 0 and report["ram_offset"] == 2097152, "RAM transfer/layout claim")
    require("FNV-1a" in report["snapshot_payload"]["checksum"], "Wrong payload checksum claim")
    events, boots, file_hashes, native = [], 0, {}, {}
    for role in ("A", "B"):
        raw = (out / f"{role}.log").read_bytes()
        samples = [json.loads(line[len("BENCH_JSON "):]) for line in raw.decode().splitlines() if line.startswith("BENCH_JSON ")]
        require(samples == report["samples"][role], "Raw BENCH_JSON differs from report")
        require(all(row["role"] == role for row in samples), "Wrong event role")
        events.extend(samples)
        integrity = report["artifact_integrity"][role]
        archive = (out / f"{role}-guest-logs.tar").read_bytes()
        require(len(archive) == integrity["archive"]["bytes"] and sha(archive) == integrity["archive"]["sha256"], "Archive SHA256")
        with tarfile.open(fileobj=io.BytesIO(archive), mode="r:") as stream:
            members = {member.name: stream.extractfile(member).read() for member in stream.getmembers() if member.isfile()}
        for metadata in [integrity["controller"], *integrity["vmm_logs"]]:
            name = Path(metadata["path"]).name
            candidates = [value for key, value in members.items() if Path(key).name == name]
            require(len(candidates) == 1, "Ambiguous archive member")
            data = candidates[0]
            require(len(data) == metadata["bytes"] and sha(data) == metadata["sha256"], "Archived file SHA256")
            saved = raw if name == "bench.log" else (out / "guest-artifacts" / role / name).read_bytes()
            require(saved == data, "Extracted raw file differs from archive")
            file_hashes[f"{role}/{name}"] = sha(data)
        fc = (out / f"{role}-firecracker.log").read_text()
        # Combined logs have filenames between entries; every API body is still
        # independently available in the SHA-verified archive members above.
        all_vmm = "\n".join((out / "guest-artifacts" / role / Path(meta["path"]).name).read_text() for meta in integrity["vmm_logs"])
        for call, key in (("create", "mem_file_path"), ("load", "backend_path")):
            bodies = []
            for line in all_vmm.splitlines():
                if f'request on "/snapshot/{call}" with body ' in line:
                    encoded = line.split(" with body ", 1)[1]
                    require(encoded.endswith("."), "API log boundary")
                    bodies.append(json.loads(json.loads(encoded[:-1])))
            require(len(bodies) == 12, f"Unexpected snapshot/{call} count")
            for body in bodies:
                backend = body if call == "create" else body["mem_backend"]
                require(backend[key] == "/dev/dax0.0", "Bulk RAM file instead of shared DAX")
        maps = re.findall(r"DAX_RAM path=/dev/dax0\.0 offset=(\d+) gpa=0 bytes=(\d+) initialize=(\w+) hva=(0x[0-9a-f]+)", all_vmm)
        require(all(int(off) == 2097152 and int(size) == 134217728 and int(hva,16) == report["fixed_ram_hva"] for off,size,init,hva in maps), "DAX mapping layout")
        false_maps = sum(row[2] == "false" for row in maps)
        require(false_maps == (0 if reuse else 12), "Snapshot remap/reuse behavior")
        boot_count = len(re.findall(r"^L2_BOOTED ", all_vmm, re.M))
        require(boot_count == (1 if reuse or role == "A" else 0), "Unexpected guest boot")
        require(len(re.findall(r"^L2_BOOTED ", fc, re.M)) == boot_count, "Combined boot count differs from archived logs")
        boots += boot_count
        kernel = (out / f"{role}-kernel-final.log").read_text()
        require(re.search(r"^0\nenabled=0 phys=0 bytes=0 available=0 failures=0$", kernel, re.M), "Kernel taint / shared KVM pool")
        if reuse:
            identities = [row for row in samples if row["event"] == "native_identity"]
            signatures = {(row["pid"],row["process_start"],row["vm_fd"],row["vcpu_fd"],row["vcpu_tid"]) for row in identities}
            require(len(identities) == 25 and len(signatures) == 1, "Worker process/FD/thread identity changed")
            native[role] = list(next(iter(signatures)))
            restores = [json.loads(line.split("DAX_REUSE_IDENTITY ",1)[1]) for line in all_vmm.splitlines() if "DAX_REUSE_IDENTITY " in line]
            require(len(restores) == 12, "Missing runtime reuse identities")
            require(all(row["ram_mapping_reused"] and row["receiver_prepared"] == prepared and all(row[key] == 0 for key in ("thread_creates","vcpu_creates","vm_creates")) for row in restores), "Reused object creation / mapping")
            require(len({(row["vm_ptr"],row["vm_fd"],row["vcpu_fd"]) for row in restores}) == 1, "Runtime reuse identity changed")
    sources = sorted((row for row in events if row["event"] == "source"), key=lambda row: row["round"])
    destinations = sorted((row for row in events if row["event"] == "destination"), key=lambda row: row["round"])
    require(len(sources) == len(destinations) == 24, "Missing handoff samples")
    for i,(source,destination) in enumerate(zip(sources,destinations)):
        require(source["round"] == destination["round"] == i and source["role"] != destination["role"], "Handoff round pair")
        require(source["role"] == ("A" if i % 2 == 0 else "B"), "Handoff direction")
        require(0 < source["state_bytes"] <= 262144 and source["state_bytes"] == destination["state_bytes"] and source["state_hash"] == destination["state_hash"], "Payload length/FNV differs")
        require(source["ram_hva"] == destination["ram_hva"] == report["fixed_ram_hva"], "RAM HVA changed")
        if i: require(source["sequence"] > sources[i-1]["sequence"], "Guest progress absent")
    complete = [row for row in events if row["event"] == "complete"]
    require(len(complete) == 2 and all(row["rounds"] == 24 and all(row[key] == 0 for key in ("errors","clock_errors","tsc_errors")) for row in complete), "Continuity completion")
    validation = report["validation"]
    require(validation["handoffs"] == 24 and validation["boot_markers"] == boots, "Derived count differs")
    sizes = sorted({row["state_bytes"] for row in sources})
    total = sum(row["state_bytes"] for row in sources)
    require(validation["state_bytes"] == sizes and validation["snapshot_payload_bytes_total"] == total, "Derived payload sizes differ")
    preparations = sorted((row for row in events if row["event"] == "reuse_prepare"), key=lambda row: row["round"])
    require(len(preparations) == (24 if prepared else 0), "Prepare count")
    if prepared:
        require(preparations == report["preparations"], "Preparation report mismatch")
        require(all(row["round"] == i and row["role"] == ("B" if i % 2 == 0 else "A") and row["seed"] == (i == 0) and row["outside_pause_to_ack"] for i,row in enumerate(preparations)), "Preparation ordering")
    maps = (out / "final-vmm.maps").read_text()
    require(re.search(r"^400000000000-400008000000 rw-s 00200000 .* /dev/dax0\.0$", maps, re.M), "Final shared DAX mapping absent")
    return {"mode": mode, "report": str(path), "handoffs": 24, "measured": 20, "warmup": 4, "state_bytes": sizes,
            "state_payload_bytes_total": total, "source_destination_fnv_matches": 24, "archived_file_sha256": file_hashes,
            "native_worker_signatures": native, "shared_ram_bytes_transferred": 0,
            "ram_evidence": "Every save/load names /dev/dax0.0; same HVA; fresh remaps initialize=false, or runtime reuse mapping retained; final rw-s DAX mapping"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--file-list", type=Path, required=True)
    args = parser.parse_args()
    entries = json.loads(args.manifest.read_text())
    results, negative, files = [], [], set()
    for entry in entries:
        path = Path(entry["report"])
        if not path.is_absolute(): path = args.manifest.parent / path
        results.append(audit(path, entry["mode"]))
        original = json.loads(path.read_text())
        for name in ("handoffs", "payload_bytes", "ram_transfer", "sample_hash", "archive_sha"):
            changed = copy.deepcopy(original)
            if name == "handoffs": changed["validation"]["handoffs"] += 1
            elif name == "payload_bytes": changed["validation"]["snapshot_payload_bytes_total"] *= 1000
            elif name == "ram_transfer": changed["ram_transfer_bytes"] = 134217728
            elif name == "sample_hash": next(row for row in changed["samples"]["A"] if row["event"] == "source")["state_hash"] ^= 1
            elif name == "archive_sha": changed["artifact_integrity"]["A"]["archive"]["sha256"] = "0" * 64
            try:
                audit(path, entry["mode"], changed)
            except ValueError as exc:
                negative.append({"mode": entry["mode"], "mutation": name, "rejected": True, "error": str(exc)})
            else: raise AssertionError(f"Accepted {name} mutation")
        files.update(str(p) for p in path.parent.rglob("*") if p.is_file())
        configuration = path.parent / "run.json"
        if not configuration.exists():
            configuration = path.parent.parent / "run.json"
        require(configuration.is_file(), "Missing retained run configuration")
        files.add(str(configuration))
    args.file_list.write_text("\n".join(sorted(files)) + "\n")
    result = {"result": "passed", "reports": results, "negative_tests": negative,
              "limitations": ["State payload checksum is FNV-1a64, not SHA256 or authentication", "Per-round state payload bytes were not archived; their hashes cannot be independently recomputed after the run", "Zero bulk RAM transfer is supported by runtime API/mapping evidence and implementation contract, not a general memory-write instrument"],
              "script_sha256": sha(Path(__file__).read_bytes())}
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"result": "passed", "reports": len(results), "handoffs": sum(row["handoffs"] for row in results), "negative_tests": len(negative), "files": len(files)}))


if __name__ == "__main__":
    main()
