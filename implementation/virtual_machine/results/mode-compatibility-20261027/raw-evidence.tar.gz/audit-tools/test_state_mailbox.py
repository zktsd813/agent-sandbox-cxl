#!/usr/bin/env python3
"""Fault-inject only the reserved mailbox of an already completed, owned lab.

No VM is started/stopped and guest RAM at/above 2 MiB is never modified.
Run only after the trace experiment has completed and before its L1 pair stops.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import secrets
import shlex
import sys

def shell(vm, body):
    return nfs.shell(vm, body, timeout=45)


def digest(vm, path):
    text = shell(vm, f"printf 'STATE_SHA='\nsha256sum {shlex.quote(path)}")
    rows = re.findall(r'^STATE_SHA=([0-9a-f]{64})\s', text.replace('\r', ''), re.M)
    assert len(rows) == 1, text
    return rows[0]


def main():
    global lab, nfs
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--source-dir', type=Path,
                        default=Path('/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine'),
                        help='Directory containing the measured lab.py/nfs_bench.py; specify explicitly when reproducing')
    parser.add_argument('--offsets', type=Path, default=Path(__file__).with_name('state-mailbox-offsets.json'),
                        help='ABI offsets emitted by the C unit fixture')
    args = parser.parse_args()
    sys.path.insert(0, str(args.source_dir.resolve()))
    import lab
    import nfs_bench as nfs
    offsets = json.loads(args.offsets.read_text())
    if args.output.exists():
        raise FileExistsError(args.output)
    report = json.loads(args.report.read_text())
    assert report['result'] == 'passed', 'Trace experiment must finish successfully first'
    config = report['config']
    assert config['dax_guest'] and not config['dax_handoff'] and not config['dax_kvm_state']
    assert all(lab.alive(vm) for vm in config['vms'].values()), 'Owned L1 process identity changed/stopped'
    assert all(1048576 <= off <= 2097152 - 4 and off % 4 == 0 for off in offsets.values())
    a, b = config['vms']['A'], config['vms']['B']
    memory = report['arguments']['memory_mib']
    source_trial = next(t for t in report['trials'] if t['result'] == 'passed')
    state_path = args.report.parent / source_trial['handoffs'][0]['state_file']
    source = state_path.read_bytes()
    assert 0 < len(source) <= 262144
    source_sha = hashlib.sha256(source).hexdigest()
    directory = '/run/trace-' + secrets.token_hex(8)
    path = directory + '/state'
    outcome = {'result': 'running', 'source_report': str(args.report.resolve()),
               'source_state_file': str(state_path), 'source_state_sha256': source_sha,
               'directory': directory, 'memory_mib': memory, 'offsets': offsets,
               'source_dir': str(args.source_dir.resolve()),
               'guest_ram_modified': False, 'cases': [], 'positive_receipts': []}
    def save():
        args.output.write_text(json.dumps(outcome, indent=2) + '\n')
    def invoke(vm, role, phase, nonce, round_, expected=0, mem=None):
        command = shlex.join(['/lab/shared-probe', 'state-mailbox', role, phase, '/dev/dax0.0',
                              path, nonce, str(round_), str(memory if mem is None else mem)])
        text = shell(vm, f"set +e\n{command}\nrc=$?\nprintf 'STATE_TEST_RC=%s\\n' \"$rc\"\nexit 0")
        codes = re.findall(r'^STATE_TEST_RC=([0-9]+)$', text.replace('\r', ''), re.M)
        assert codes == [str(expected)], text
        rows = [json.loads(line.removeprefix('STATE_MAILBOX_JSON ')) for line in text.splitlines()
                if line.startswith('STATE_MAILBOX_JSON ')]
        if expected == 0:
            assert len(rows) == 1, text
            r = rows[0]
            assert r['phase'] == phase and r['role'] == role and r['nonce'] == nonce and r['round'] == round_
            assert r['offset'] == 1048576 and r['capacity'] == 262144 and r['memory_bytes'] == memory * 1048576
            return r
        assert not rows, text
        return {'exit_code': expected, 'raw': text}
    def word(vm, role, field, value=None):
        off = offsets[field]
        text = shell(vm, f'/lab/shared-probe dax-word {role} /dev/dax0.0 {off}' +
                     (f' {value}' if value is not None else ''))
        rows = re.findall(r'^LAB_DAX_WORD=0x([0-9a-f]{8})$', text.replace('\r', ''), re.M)
        assert len(rows) == 1, text
        return int(rows[0], 16)
    try:
        for role, vm in config['vms'].items():
            text = shell(vm, "if pidof firecracker >/dev/null; then echo ACTIVE_FIRECRACKER; exit 1; fi\n"
                            f"mkdir -m 700 {directory}\nprintf 'HELPER_SHA='\nsha256sum /lab/shared-probe")
            expected = config['prepared']['artifacts']['shared-probe']
            assert re.findall(r'^HELPER_SHA=([0-9a-f]{64})\s', text.replace('\r', ''), re.M) == [expected]
        nfs.upload(a, path, source)
        nfs.upload(b, path, b'target-sentinel-preserve-on-rejection\n')
        for field, replacement in [('published', 0), ('schema', 'xor'), ('nonce', 'xor'),
                                   ('state_round', 2), ('memory_bytes', 'xor'), ('state_size', 0),
                                   ('state_size', 262145), ('state_hash', 'xor'), ('sequence', ord('B')),
                                   ('state', 'xor'), ('acknowledged', 1)]:
            nonce = secrets.token_hex(8)
            published = invoke(a, 'A', 'publish', nonce, 1)
            prior = word(a, 'A', field)
            changed = prior ^ 1 if replacement == 'xor' else replacement
            word(a, 'A', field, changed)
            before = digest(b, path)
            failure = invoke(b, 'B', 'receive', nonce, 1, expected=3)
            after = digest(b, path)
            assert before == after
            outcome['cases'].append({'name': f'corrupt_{field}_{changed}', 'publish': published,
                                     'offset': offsets[field], 'before_word': prior, 'after_word': changed,
                                     'destination_sha256_before': before, 'destination_sha256_after': after,
                                     **failure})
            save()
        nonce = secrets.token_hex(8)
        pub1 = invoke(a, 'A', 'publish', nonce, 1)
        before = digest(b, path)
        premature = invoke(b, 'B', 'publish', nonce, 2, expected=3)
        assert digest(b, path) == before
        outcome['cases'].append({'name': 'round2_before_round1_consumed', **premature})
        duplicate = invoke(a, 'A', 'publish', nonce, 1, expected=3)
        outcome['cases'].append({'name': 'duplicate_publish', **duplicate})
        wrong_role = invoke(a, 'A', 'receive', nonce, 1, expected=2)
        outcome['cases'].append({'name': 'wrong_receive_role', **wrong_role})
        recv1 = invoke(b, 'B', 'receive', nonce, 1)
        assert digest(b, path) == source_sha
        duplicate = invoke(b, 'B', 'receive', nonce, 1, expected=3)
        assert digest(b, path) == source_sha
        outcome['cases'].append({'name': 'duplicate_receive', 'destination_sha256': source_sha, **duplicate})
        pub2 = invoke(b, 'B', 'publish', nonce, 2)
        recv2 = invoke(a, 'A', 'receive', nonce, 2)
        assert digest(a, path) == source_sha
        for pub, recv in [(pub1, recv1), (pub2, recv2)]:
            for key in ('nonce', 'round', 'schema', 'offset', 'capacity', 'memory_bytes', 'state_bytes', 'state_hash', 'source_role'):
                assert pub[key] == recv[key], key
        outcome['positive_receipts'] = [pub1, recv1, pub2, recv2]
        outcome['result'] = 'passed'
    except BaseException as error:
        outcome.update(result='failed', error=repr(error))
        raise
    finally:
        save()
    print(json.dumps({'result': outcome['result'], 'negative_cases': len(outcome['cases']), 'output': str(args.output)}))


if __name__ == '__main__':
    main()
