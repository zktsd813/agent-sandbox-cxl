/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI_LINUX_KVM_DAX_H
#define _UAPI_LINUX_KVM_DAX_H
#include <linux/types.h>
#include <linux/ioctl.h>

/* Private laboratory ABI, CONFIG_KVM_DAX_POOL_TEST only. */
struct kvm_dax_handoff {
	__u64 vm_offset, vcpu_offset, vmcs_offset, run_offset;
	__u64 generation, kernel_ns, pool_used;
	__u64 vm_creates, vcpu_creates;
	__u64 ram_hva, ram_bytes;
	__u32 node, flags;
	__u64 quiesce_ns, mmu_drain_ns, binding_ns;
	__u64 ept_root_offset, ept_page_count;
};
#define KVM_DAX_EXPORT _IOR(0xae, 0xf0, struct kvm_dax_handoff)
#define KVM_DAX_ATTACH _IOWR(0xae, 0xf1, struct kvm_dax_handoff)
#define KVM_DAX_DETACH _IOR(0xae, 0xf2, struct kvm_dax_handoff)
#define KVM_DAX_VCPU _IO(0xae, 0xf3)
#define KVM_DAX_PEEK _IOR(0xae, 0xf4, struct kvm_dax_handoff)
#define KVM_DAX_REATTACH _IOWR(0xae, 0xf5, struct kvm_dax_handoff)
#define KVM_DAX_IRQFD_QUIESCE _IO(0xae, 0xf6)
/* Optional timing data in the reserved first arena page; not migration state. */
#define KVM_DAX_PROFILE_OFFSET 512
struct kvm_dax_profile {
	__u64 detach[8], attach[8];
};
#define KVM_DAX_RESUME_PROFILE_OFFSET 640
/* Destination-local clock samples, overwritten at each attach. Diagnostic only. */
struct kvm_dax_resume_profile {
	__u64 enabled, generation, run_ns, entry_ready;
	__u64 entry_ns, guest_tsc, virtual_tsc_khz, sample_span_ns, entry_rip;
	__u64 exit_ready, exit_ns, exit_reason, entry_failed;
};
#endif
