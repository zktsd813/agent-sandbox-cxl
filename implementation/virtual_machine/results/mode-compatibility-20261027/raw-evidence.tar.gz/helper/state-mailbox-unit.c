#define main shared_probe_program_main
#include "/tmp/agent-sandbox-cxl-microvm-main-20261023/implementation/virtual_machine/shared_probe.c"
#undef main
#include <assert.h>
int main(void) {
    struct handoff_control c = {0};
    uint64_t nonce = UINT64_C(0x123456789abcdef0), memory = 512 * UINT64_C(1024) * 1024;
    assert(!state_mailbox_publish_error(&c, nonce, 1, memory));
    atomic_store(&c.nonce, nonce); c.schema = HANDOFF_SCHEMA; c.state_round = 1;
    c.state_size = 17; memcpy(c.state, "checkpoint bytes!", c.state_size);
    c.state_hash = checkpoint_hash(c.state, c.state_size); c.memory_bytes = memory; c.sequence = 'A';
    atomic_store(&c.published, 1);
    assert(!state_mailbox_receive_error(&c, nonce, 1, memory));
    assert(state_mailbox_publish_error(&c, nonce, 1, memory));
    assert(state_mailbox_publish_error(&c, nonce, 2, memory));
#define REJECT(field, value) do { uint64_t saved = c.field; c.field = value; assert(state_mailbox_receive_error(&c, nonce, 1, memory)); c.field = saved; } while (0)
    REJECT(schema, 0); REJECT(state_round, 2); REJECT(sequence, 'B'); REJECT(memory_bytes, memory + 1);
    REJECT(state_size, 0); REJECT(state_size, sizeof(c.state) + 1); REJECT(state_hash, c.state_hash ^ 1);
    c.state[0] ^= 1; assert(state_mailbox_receive_error(&c, nonce, 1, memory)); c.state[0] ^= 1;
    assert(state_mailbox_receive_error(&c, nonce ^ 1, 1, memory));
    atomic_store(&c.published, 0); assert(state_mailbox_receive_error(&c, nonce, 1, memory)); atomic_store(&c.published, 1);
    atomic_store(&c.acknowledged, UINT64_MAX); assert(state_mailbox_receive_error(&c, nonce, 1, memory));
    atomic_store(&c.acknowledged, 1); assert(state_mailbox_receive_error(&c, nonce, 1, memory));
    assert(!state_mailbox_publish_error(&c, nonce, 2, memory));
    assert(state_mailbox_publish_error(&c, nonce ^ 1, 2, memory));
    assert(state_mailbox_publish_error(&c, nonce, 2, memory + 1));
    assert(state_mailbox_path_valid("/run/trace-0123456789abcdef/state"));
    assert(!state_mailbox_path_valid("/run/trace-0123456789abcde/state"));
    assert(!state_mailbox_path_valid("/run/trace-0123456789abcdeg/state"));
    assert(!state_mailbox_path_valid("/tmp/trace-0123456789abcdef/state"));
    assert(!state_mailbox_path_valid("/run/trace-0123456789abcdef/../state"));
    assert(!state_mailbox_path_valid("/run/trace-0123456789abcdef/state/"));
    puts("state mailbox unit checks passed");
    printf("{\"nonce\":%zu,\"published\":%zu,\"acknowledged\":%zu,\"schema\":%zu,\"state_round\":%zu,\"state_size\":%zu,\"state_hash\":%zu,\"memory_bytes\":%zu,\"sequence\":%zu,\"state\":%zu}\n",
       1048576+offsetof(struct handoff_control,nonce),1048576+offsetof(struct handoff_control,published),
       1048576+offsetof(struct handoff_control,acknowledged),1048576+offsetof(struct handoff_control,schema),
       1048576+offsetof(struct handoff_control,state_round),1048576+offsetof(struct handoff_control,state_size),
       1048576+offsetof(struct handoff_control,state_hash),1048576+offsetof(struct handoff_control,memory_bytes),
       1048576+offsetof(struct handoff_control,sequence),1048576+offsetof(struct handoff_control,state));
    return 0;
}
